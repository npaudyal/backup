
import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import edu.olemiss.csci211.*;

public class A2 {

	public static final String root_md_filename = new String("blocks/_root.md");
	
	public static void main(String[] args) throws IOException{
		
		VirtualDirectory root;
		
		if (new File(root_md_filename).exists()) {
		
			System.out.print("Found "+root_md_filename + ". Trying to read saved filesystem...");
			root = VirtualDirectory.createFromFile(root_md_filename);
			System.out.println("done.");
			
		} else {
			cleanBlockStore("blocks");
			root = buildFSFromScratch();
		}
		
		
		Shell shell = new Shell(root, System.in);
		
		shell.run();
		
	}
	
	public static void cleanBlockStore(String realBlockDirName) {
		
		for(File file : new File("./" + realBlockDirName).listFiles()) {
		    if (!file.isDirectory() && !file.isHidden()) {
		    	//System.out.println("deleting "+ file);
		        file.delete();
		    }
		}
	}
	
	public static VirtualDirectory buildFSFromScratch() {
		
		System.out.print("Building new virtual filesystem...");
		
		// By default, blocks are written to the "blocks" directory, so the only
		// time we need 2 arguments for VirtualFile or VirtualDirectory constructors
		// is when the virtual name differs from the real file name. The root
		// directory constructed below is an example.
		
		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "blocks/root");
		
		// A simple example of an image file.
		VirtualFile hamster = new VirtualFile("hamster"); // assumes "blocks/hamster" is the basename
		hamster.importFile("images/hamster.jpg");
		root.addSubFile(hamster);
	
		
		// another image file, but added using a single line.
		root.addSubFile(new VirtualFile("sasha").importFile("images/IMG_0148.jpg"));

		
		//VirtualDirectory users = new VirtualDirectory("users","blocks/users");
		VirtualDirectory users = new VirtualDirectory("users");
		root.addSubFile(users);

		VirtualDirectory smith = new VirtualDirectory("smith");
		users.addSubFile(smith);
		
		VirtualDirectory jones = new VirtualDirectory("jones");
		users.addSubFile(jones);
		
		VirtualDirectory peter = new VirtualDirectory("peter");
		users.addSubFile(peter);

		VirtualDirectory paul = new VirtualDirectory("paul");
		users.addSubFile(paul);
		
		VirtualDirectory mary = new VirtualDirectory("mary");
		users.addSubFile(mary);
		
		


		smith.addSubFile(new VirtualFile("pom").importFile("images/8py96sh8bbw11.jpg"));
		VirtualFile horse = new VirtualFile("horse").importFile("images/okpsfss6n8w11.jpg");
		smith.addSubFile(horse);
		
		jones.addSubFile(horse);
		jones.addSubFile(new VirtualFile("totallydifferenthorse").importFile("images/okpsfss6n8w11.jpg"));
		paul.addSubFile(new VirtualFile("ronperlman").importFile("images/3gm96zxxjcw11.jpg"));
		paul.addSubFile(new VirtualFile("catsoup").importFile("images/31izsty0u9w11.jpg"));
		
		for(int i=0; i<512; i++) {
			
			String name = String.format("%s%03d", "cat",i);
			VirtualDirectory v = new VirtualDirectory(name);
			mary.addSubFile(v);
		}
		
		
		root.flush();
		
		root.writeToFile(root_md_filename);

		System.out.println("done.");
		return root;
		
	}
	
}
