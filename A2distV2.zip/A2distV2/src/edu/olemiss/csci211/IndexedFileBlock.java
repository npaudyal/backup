package edu.olemiss.csci211;

import java.io.Serializable;

/** A file block associated with an integer index. The index is used by the compareTo() method.
 * 
 * @author rhodes
 *
 */
public class IndexedFileBlock extends FileBlock implements Comparable<IndexedFileBlock>{
	
	int index;
	
	/** Construct an IndexedFileBlock using the given filename and index. The file
	 * must already exist.
	 * 
	 * @param filename the name of the file to be read.
	 * @param index an arbitrary integer index. Used to order blocks via compareTo()
	 * @throws IllegalArgumentException if the file can't be fully read.
	 */
	public IndexedFileBlock(String filename, int index) {
		
		super(filename);
		this.index = index;
	}

	
	/** Construct an IndexedFileBlock using the given filename and index. If the file
	 * doesn't exist, a new file with the given name and data size will be created.
	 * 
	 * @param filename the name of the file to be created and/or read.
	 * @param size the number of bytes in the data portion of the new file (if created)
	 * @param index an arbitrary integer index. Used to order blocks via compareTo()
	 * @throws IllegalArgumentException if the file can't be created.
	 */
	public IndexedFileBlock(String filename, int size, int index) {
		
		super(filename, size);
		this.index = index;
	}

	
	
	
	/** This copy constructor makes a copy of the given block. 
	 * 
	 * @param b the block to copy.
	 * @throws IllegalArgumentException if b is null.
	 */
	public IndexedFileBlock(IndexedFileBlock b) {
		
		super(b);

		this.index = b.index;
	}
	
	
	
	/** Return an integer index associated with this block.
	 * 
	 * @return an integer index
	 */
	public int getIndex() {
		
		return this.index;
	}

	/** Set the contents of this Block to be a copy of the given block. 
	 *
	 * @param newblock the block to be copied.
	 */
	public void assign(IndexedFileBlock newblock) {
		
		super.assign(newblock);

		this.index = newblock.index;
	}

	/** Return an integer indicating if this block index is less than, equal to, or greater than the index of the given block.
	 * @param o the other block.
	 * @return an int with value 0 if indices are equal, &lt; 0 if this.index &lt; o.index, or &gt; 0 if this.index &gt; o.index
	 */
	@Override
	public int compareTo(IndexedFileBlock o) {
		
		return this.index - o.index;

	}
	
	

}