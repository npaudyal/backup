package edu.olemiss.csci211;

import java.io.DataOutputStream;

/** An interface for classes that can write themselves to a file.
 * 
 * @author rhodes
 *
 */
public interface Writeable {
	
	
	/** Write the object to the given stream.
	 *  The stream should already be open for writing.
	 * @param dos an open DataOutputStream
	 * @throws IllegalArgumentException if the stream can't be written.
	 */
	void write(DataOutputStream dos);
}
