package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;

public class VirtualFileOutputStreamTest {

	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrow() {

		VirtualFileOutputStream vfos = new  VirtualFileOutputStream(null);		
	}

	
	@Test
	public void constructorShouldNOTThrow() {
		
		VirtualFile vFile = new VirtualFile("foo");
		VirtualFileOutputStream vfos = new  VirtualFileOutputStream(vFile);		
	}

	@Test
	public void write1() {
		
		VirtualFile vFile = new VirtualFile("foo");
		VirtualFileOutputStream vfos = new  VirtualFileOutputStream(vFile);		
		
		vfos.write(12);
		
		byte [] data = vFile.iterator().next().data();
		
		assertEquals(12, data[0]);
	}

	
	@Test
	public void write2() {
		
		VirtualFile vFile = new VirtualFile("foo");
		VirtualFileOutputStream vfos = new  VirtualFileOutputStream(vFile);		
		
		vfos.write(12);
		vfos.write(177);
		
		byte [] data = vFile.iterator().next().data();
		
		assertEquals(177, data[1] & 0xFF);
	}

	@Test
	public void write3() {
		
		VirtualFile vFile = new VirtualFile("foo");
		VirtualFileOutputStream vfos = new  VirtualFileOutputStream(vFile);		
		
		for(int i=0; i<1000; i++) {
			vfos.write(i & 0xFF);
		}
		
		Iterator<IndexedFileBlock> iter = vFile.iterator();
		iter.next();
		
		byte [] data = iter.next().data();
		
		assertEquals(0, data[0] & 0xFF);
	}

}
