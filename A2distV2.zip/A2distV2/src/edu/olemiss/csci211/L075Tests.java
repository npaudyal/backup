package edu.olemiss.csci211;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class L075Tests {

	List<Integer> q;
	List<Integer> s;
	
	@Before
	public void setup() {
		
		q = new LinkedQueue<Integer>();
		s = new LinkedStack<Integer>();
	}
	
	@After
	public void tearDown() {
		
		// clean up the scrap directory
		for(File file : new File("./scrap").listFiles()) {
		    if (!file.isDirectory() && !file.isHidden()) {
		    	//System.out.println("deleting "+ file);
		        file.delete();
		    }
		}
	}
	
	
	//////////////////List Interface Tests////////////////
	
	@Test
	public void listFindTest1() {
		
		q.add(1);
		q.add(2);
		q.add(3);
		
		assertEquals(new Integer(1), q.find(1));
	}

	@Test
	public void listFindTest2() {
		
		q.add(1);
		q.add(2);
		q.add(3);
		
		assertEquals(new Integer(2), q.find(2));
	}
	
	@Test
	public void listFindTest3() {
		
		q.add(1);
		q.add(2);
		q.add(3);
		
		assertEquals(new Integer(3), q.find(3));
	}
	
	@Test
	public void listFindTest4() {
		
		q.add(1);
		q.add(2);
		q.add(3);
		
		assertEquals(null, q.find(4));
	}

	@Test
	public void listFindTest5() {
		
		s.add(1);
		s.add(2);
		s.add(3);
		
		assertEquals(new Integer(3), s.find(3));
	}
	
	@Test
	public void listFindTest6() {
		
		s.add(1);
		s.add(2);
		s.add(3);
		
		assertEquals(null, s.find(4));
	}

	///////////////////VirtualDirectory.findSubFile/////////////////////////
	
	@Test
	public void VDirectoryFindSubFile1() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		VirtualDirectory d1 = new VirtualDirectory("dir","scrap/dir");
		
		root.addSubFile(d1);
		
		VirtualFile s = root.findSubFile("dir"); 
		
		assertEquals(d1,s);
	}
	
	@Test
	public void VDirectoryFindSubFile2() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		VirtualDirectory d1 = new VirtualDirectory("dir","scrap/dir");
		VirtualDirectory d2 = new VirtualDirectory("dir2","scrap/dir2");
		
		root.addSubFile(d1);
		root.addSubFile(d2);
		
		VirtualFile s = root.findSubFile("dir2"); 
		
		assertEquals(d2,s);
	}

	@Test
	public void VDirectoryFindSubFile3() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		VirtualDirectory d1 = new VirtualDirectory("dir","scrap/dir");
		VirtualDirectory d2 = new VirtualDirectory("dir2","scrap/dir2");
		
		root.addSubFile(d1);
		root.addSubFile(d2);
		
		VirtualFile s = root.findSubFile("dir3"); 
		
		assertEquals(null,s);
	}

	/////////////////////////VirtualDirectory.writeToFile////////////////////////////////

	@Test
	public void VDirectoryWriteToFileShouldNOTthrow() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
				
		root.writeToFile("scrap/root1");
	}

	@Test (expected = IllegalArgumentException.class)
	public void VDirectoryWriteToFileShouldThrow() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		root.writeToFile(""); // this just can't be good!
	}

	
	@Test
	public void VDirectoryWriteToFile1() throws IOException, ClassNotFoundException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");		
		
		VirtualDirectory d1 = new VirtualDirectory("dir", "scrap/dir");
		VirtualDirectory d2 = new VirtualDirectory("dir2", "scrap/dir2");
		
		root.addSubFile(d1);
		root.addSubFile(d2);
		
		root.writeToFile("scrap/root1");
		
		
		// writeToFile should just be serializing VirtualDirectoryMetaData
		// so we can test it with the following 75% level code. 
		FileInputStream fis = new FileInputStream("scrap/root1");
		ObjectInputStream ois = new ObjectInputStream(fis);
	
		VirtualDirectoryMetaData m2 = (VirtualDirectoryMetaData) ois.readObject();
		
		ois.close();
		
		m2.getSubFileMetaDataList();
		
		assertEquals(2, m2.getSubFileMetaDataList().size());
	}

	@Test
	public void VDirectoryWriteToFile2() throws IOException, ClassNotFoundException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");		
		
		VirtualDirectory d1 = new VirtualDirectory("dir", "scrap/dir");
		VirtualFile f2 = new VirtualDirectory("file2", "scrap/file2");  //VirtualFile is not serializable,
																		// but that shouldn't matter.
		
		root.addSubFile(d1);
		root.addSubFile(f2);
		
		root.writeToFile("scrap/root1");
		
		
		// writeToFile should just be serializing VirtualDirectoryMetaData
		// so we can test it with the following 75% level code. 
		FileInputStream fis = new FileInputStream("scrap/root1");
		ObjectInputStream ois = new ObjectInputStream(fis);
	
		VirtualDirectoryMetaData m2 = (VirtualDirectoryMetaData) ois.readObject();
		
		ois.close();
		
		m2.getSubFileMetaDataList();
		
		assertEquals(2, m2.getSubFileMetaDataList().size());
	}

	
	
	
	
	//////////////////VirtualDirectoryMetaData Serialization////////////////
	
	@Test
	public void VDMDSerializeShouldNOTthrow() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectoryMetaData m = root.createVirtualMetaData(); 
		
		FileOutputStream fos = new FileOutputStream("scrap/root.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(m);
		
		oos.close();
	}

	@Test
	public void VDMDSerializeShouldNOTthrow2() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory d1 = new VirtualDirectory("dir","scrap/dir");
		
		root.addSubFile(d1);
		
		VirtualDirectoryMetaData m = root.createVirtualMetaData(); 
		
		FileOutputStream fos = new FileOutputStream("scrap/root.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(m);
		
		oos.close();
	}

	@Test
	public void VDMDSerializeShouldNOTthrow3() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory d1 = new VirtualDirectory("dir","scrap/dir");
		VirtualDirectory d2 = new VirtualDirectory("dir2","scrap/dir2");
		
		root.addSubFile(d1);
		root.addSubFile(d2);
		
		VirtualDirectoryMetaData m = root.createVirtualMetaData(); 
		
		FileOutputStream fos = new FileOutputStream("scrap/root.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(m);
		
		oos.close();
	}

	
	@Test
	public void VDMDDeSerializeShouldNOTthrow() throws IOException, ClassNotFoundException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectoryMetaData m = root.createVirtualMetaData();
		
		FileOutputStream fos = new FileOutputStream("scrap/root.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(m);
		oos.close();
		
		// Deserialize it now.
		FileInputStream fis = new FileInputStream("scrap/root.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
	
		VirtualDirectoryMetaData m2 = (VirtualDirectoryMetaData) ois.readObject();
		
		oos.close();
		ois.close();
	}

	@Test
	public void VDMDDeSerialize1() throws IOException, ClassNotFoundException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectoryMetaData m = root.createVirtualMetaData();
		
		FileOutputStream fos = new FileOutputStream("scrap/root.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		// serialize the VirtualDirectoryMetaData
		oos.writeObject(m);
		oos.close();
		
		// Deserialize it now.
		FileInputStream fis = new FileInputStream("scrap/root.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
	
		VirtualDirectoryMetaData m2 = (VirtualDirectoryMetaData) ois.readObject();
		
		oos.close();
		ois.close();
		
		m2.getSubFileMetaDataList();
		
		assertEquals(0, m2.getSubFileMetaDataList().size());
	}
	
	@Test
	public void VDMDDeSerialize2() throws IOException, ClassNotFoundException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory d1 = new VirtualDirectory("dir","scrap/dir");
		VirtualDirectory d2 = new VirtualDirectory("dir2","scrap/dir2");

		root.addSubFile(d1);
		root.addSubFile(d2);
		
		VirtualDirectoryMetaData m = root.createVirtualMetaData();
		
		FileOutputStream fos = new FileOutputStream("scrap/root.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		// serialize the VirtualDirectoryMetaData
		oos.writeObject(m);
		oos.close();
		
		// Deserialize it now.
		FileInputStream fis = new FileInputStream("scrap/root.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
	
		VirtualDirectoryMetaData m2 = (VirtualDirectoryMetaData) ois.readObject();
		
		oos.close();
		ois.close();
		
		m2.getSubFileMetaDataList();
		
		assertEquals(2, m2.getSubFileMetaDataList().size());
		
	}

	@Test
	public void VDMDDeSerialize3() throws IOException, ClassNotFoundException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory d1 = new VirtualDirectory("dir","scrap/dir");
		VirtualFile f2 = new VirtualFile("dir2","scrap/dir2");

		root.addSubFile(d1);
		root.addSubFile(f2);
		
		VirtualDirectoryMetaData m = root.createVirtualMetaData();
		
		FileOutputStream fos = new FileOutputStream("scrap/root.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		// serialize the VirtualDirectoryMetaData
		oos.writeObject(m);
		oos.close();
		
		// Deserialize it now.
		FileInputStream fis = new FileInputStream("scrap/root.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
	
		VirtualDirectoryMetaData m2 = (VirtualDirectoryMetaData) ois.readObject();
		
		oos.close();
		ois.close();
		
		m2.getSubFileMetaDataList();
		
		assertEquals(2, m2.getSubFileMetaDataList().size());
		
	}

	

	
	

	
}
