
package edu.olemiss.csci211;

import java.util.zip.CRC32;

/** An interface for objects that can be checked for validity. For our purposes,
 * an object is valid if the checksum data member matches the checksum computed by 
 * Java's {@link CRC32} class. 
 * 
 * @author rhodes
 *
 */
public interface Checkable {

	/** Evaluate whether the checksum data member matches the checksum computed from the data.
	 * 
	 * @return true if the checksums match, false otherwise.
	 */
	public default boolean isValid() {
		
		return getCheckSumField() == computeCheckSum();
	}
	
	
	
	/** Compute a checksum from a data array using Java's CRC32 class.
	 * 
	 * @return The CRC32 checksum for the data.
	 */
	public long computeCheckSum();

	
	/** Compute a checksum from a data array using Java's CRC32 class. Only the first
	 * numBytes bytes of the data array are considered.
	 * 
	 * @param numBytes the number of bytes to consider.
	 * @return The CRC32 checksum for the data.
	 */
	public long computeCheckSum(int numBytes);

	
	
	/** Return the value stored in this object's checksum data member.
	 * 
	 * @return The value of the checksum field.
	 */
	public long getCheckSumField();

	
	
	/** Set this object's checksum data member
	 * to a new value calculated from the data.
	 * 
	 */
	public void resetCheckSum();

}
