package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class VirtualFileInputStreamTest {

	@Test
	public void readTest1() throws IOException {
		
		VirtualFileMetaData vfmd = new VirtualFileMetaData("UnitTestData/testRead");
		VirtualFile vtf = new VirtualFile(vfmd);
		VirtualFileInputStream vfis = new VirtualFileInputStream(vtf);
		
		for(int i=0; i<100; i++){
			int v= vfis.read();
			//System.out.println(v);
			assertEquals(i / 50, v);
		}
		
		int v= vfis.read();
		vfis.close();
		assertEquals(-1, v);
	}

}
