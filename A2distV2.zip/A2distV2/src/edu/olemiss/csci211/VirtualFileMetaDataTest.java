package edu.olemiss.csci211;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class VirtualFileMetaDataTest {

	
	@Test
	public void constructorOneShouldntThrow() {
		
		new VirtualFileMetaData(new String [] {"Foo", "Bar"}, Block.NO_CHECKSUM);
		
	}

	@Test (expected = IllegalArgumentException.class)
	public void constructorOneShoulThrowOnNullNamesArray() {
		
		new VirtualFileMetaData(null, 42);
	}

	@Test (expected = IllegalArgumentException.class)
	public void constructorOneShouldThrowOnZeroLengthNamesArray() {
				
		new VirtualFileMetaData(new String[0], Block.NO_CHECKSUM);
	}

	@Test (expected = IllegalArgumentException.class)
	public void constructorOneShoulThrowOnNullName() {
		
		String [] names = new String[2];
		
		names[0] = new String("f1");
		//names[1] is null
		
		new VirtualFileMetaData(names, 42);
	}



	
//	@Test
//	public void constructorTwoShouldntThrow() {
//		
//		VirtualFile tf = new VirtualFile( new String[] {"A1UnitTestData/f1", "A1UnitTestData/f2"} );
//		
//		new VirtualFileMetaData(tf);
//	}

	
	@Test
	public void constructorThreeShouldntThrow() {
				
		new VirtualFileMetaData("A1UnitTestData/mdr2");
	}

	@Test (expected = IllegalArgumentException.class)
	public void constructorThreeShouldThrowOnNullName() {
				
		new VirtualFileMetaData((String)null);
	}


	
//	@Test
//	public void writeShouldntThrow() {
//		
//		VirtualFile tf = new VirtualFile( new String[] {"A1UnitTestData/f1", "A1UnitTestData/f2"} );
//		
//		VirtualFileMetaData fm = new VirtualFileMetaData(tf);
//		
//		fm.write("A1UnitTestData/mdw2");
//	}


	
	
//	@Ignore
//	public void write() {
//		
//		//TapeFile tf = new TapeFile( new String[] {"f1", "f2", "f3", "f4"} );
//		
//		VirtualFile tf = new VirtualFile( new String[] {} );
//		
//		VirtualFileMetaData fm = new VirtualFileMetaData(tf);
//		
//		fm.write("A1UnitTestData/mdr0");
//	}

	@Test (expected = IllegalArgumentException.class)
	public void readShouldThrow0() {
				
		VirtualFileMetaData fm = new VirtualFileMetaData(new String [] {"ignore_me"}, Block.NO_CHECKSUM);
		
		fm.read("A1UnitTestData/mdr0");
	}

	
	
	@Test
	public void readShouldntThrow1() {
				
		VirtualFileMetaData fm = new VirtualFileMetaData(new String [] {"ignore_me"}, Block.NO_CHECKSUM);
		
		fm.read("A1UnitTestData/mdr1");
	}
	
	@Test
	public void readShouldntThrow2() {
				
		VirtualFileMetaData fm = new VirtualFileMetaData(new String [] {"ignore_me"}, Block.NO_CHECKSUM);
		
		fm.read("A1UnitTestData/mdr2");
	}

	
}
