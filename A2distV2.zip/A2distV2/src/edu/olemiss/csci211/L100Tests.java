package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;

public class L100Tests {


	@After       
	public void tearDown() {
		
		// clean up the scrap directory
		for(File file : new File("./scrap").listFiles()) {
		    if (!file.isDirectory() && !file.isHidden()) {
		    	//System.out.println("deleting "+ file);
		        file.delete();
		    }
		}
	}

	@Test (expected = IllegalArgumentException.class)
	public void importFileShouldThrow() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1","scrap/f1");
		
		vf1.importFile("not_there");	
	}


	@Test
	public void importFile1() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1", "scrap/f1");
		
		vf1.importFile("UnitTestData/f1");
		
		VirtualFileInputStream s = new VirtualFileInputStream(vf1);
		
		// In a unix shell, you can display the bytes of the file with
		// od -tx1 f1 
		// Byte values will be in hex, and offsets for each row will be
		// in base 8 (octal)
		assertEquals(0x79, s.read());
		assertEquals(0x70, s.read());
		assertEquals(0xD2, s.read());
		
		s.close();		
	}
	
	@Test
	public void importFile2() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1","scrap/f1");
		
		vf1.importFile("UnitTestData/f1");
		
		VirtualFileInputStream s = new VirtualFileInputStream(vf1);
	
		// "UnitTestData/f1" is 512 bytes long, so we
		// should get an EOF (-1) after this loop.
		for(int i=0; i<512; i++) {
			
			s.read();
		}
		
		assertEquals(-1, s.read());
		
		s.close();		
	}

	@Test
	public void importFile3() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1","scrap/f1");
		
		vf1.importFile("UnitTestData/f1");
		
		VirtualFileInputStream s = new VirtualFileInputStream(vf1);
	
		for(int i=0; i<256; i++) {
			
			s.read();
		}
		
		//spot check half way through
		assertEquals(0x42, s.read()); 
		assertEquals(0xBC, s.read()); 
		assertEquals(0x07, s.read()); 
		
		s.close();		
	}

	/////////////////////VirtualDirectory.findAll()/////////////////////////////
	@Test
	public void findAll1() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1","scrap/f1");
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		root.addSubFile(vf1);
		

		
		assertEquals("./f1	type:file	bytes on disk:512	blocks:1\n", root.findAll("f1"));
	}

	@Test
	public void findAll2() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1 ","scrap/f1"); // note the space character after f1
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		root.addSubFile(vf1);
		
		assertEquals("", root.findAll("f1"));
	}

	@Test
	public void findAll3() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1 ","scrap/f1"); // note the space character after f1
		VirtualFile vf2 = new VirtualFile("f2","scrap/f2"); 
		VirtualFile vf3 = new VirtualFile("f3","scrap/f3");
		VirtualFile vf4 = new VirtualFile("f4","scrap/f4");
		VirtualFile vf5 = new VirtualFile("f5","scrap/f5");
		
		vf4.importFile("UnitTestData/f2");
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		root.addSubFile(vf1);
		root.addSubFile(vf2);
		root.addSubFile(vf3);
		root.addSubFile(vf4);
		root.addSubFile(vf5);
		root.flush();
		
		assertEquals("./f4	type:file	bytes on disk:1024	blocks:2\n", root.findAll("f4"));
	}

	@Test
	public void findAll4() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1 ","scrap/f1"); // note the space character after f1
		VirtualFile vf2 = new VirtualFile("f2","scrap/f2"); 
		VirtualDirectory vd3 = new VirtualDirectory("f3","scrap/d3");
		VirtualFile vf4 = new VirtualFile("f4","scrap/f4");
		VirtualFile vf5 = new VirtualFile("f5","scrap/f5");
		
		vf4.importFile("UnitTestData/f2");
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		root.addSubFile(vf1);
		root.addSubFile(vf2);
		root.addSubFile(vd3);
		vd3.addSubFile(vf4);
		vd3.addSubFile(vf5);
		root.flush();
		
		assertEquals("./f3/f4	type:file	bytes on disk:1024	blocks:2\n", root.findAll("f4"));
	}

	@Test
	public void findAll5() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1 ","scrap/f1"); // note the space character after f1
		VirtualFile vf2 = new VirtualFile("t","scrap/f2"); 
		VirtualDirectory vd3 = new VirtualDirectory("f3","scrap/d3");
		VirtualFile vf4 = new VirtualFile("f4","scrap/f4");
		VirtualFile vf5 = new VirtualFile("t","scrap/f5");
		
		vf4.importFile("UnitTestData/f2");
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		root.addSubFile(vf1);
		root.addSubFile(vf2);
		root.addSubFile(vd3);
		vd3.addSubFile(vf4);
		vd3.addSubFile(vf5);
		root.flush();
		
		assertEquals(	"./t	type:file	bytes on disk:512	blocks:1\n" + 
						"./f3/t	type:file	bytes on disk:512	blocks:1\n", root.findAll("t"));
	}

	@Test
	public void findAll6() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("f1 ","scrap/f1"); // note the space character after f1
		VirtualFile vf2 = new VirtualFile("t","scrap/f2"); 
		VirtualDirectory vd3 = new VirtualDirectory("d3","scrap/d3");
		VirtualFile vf4 = new VirtualFile("f4","scrap/f4");
		VirtualFile vf5 = new VirtualFile("f5","scrap/f5");
		VirtualDirectory vd6 = new VirtualDirectory("t","scrap/d6");
		VirtualDirectory vd7 = new VirtualDirectory("t","scrap/d7");
		
		vf4.importFile("UnitTestData/f2");
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		root.addSubFile(vf1);
		root.addSubFile(vf2);
		root.addSubFile(vd3);
		vd3.addSubFile(vf4);
		vd3.addSubFile(vf5);
		vd3.addSubFile(vd6);
		vd6.addSubFile(vd7);
		root.flush();
		
		assertEquals(	"./t	type:file	bytes on disk:512	blocks:1\n" + 
						"./d3/t	type:dir	bytes on disk:1024	blocks:2\n" + 
						"./d3/t/t	type:dir	bytes on disk:512	blocks:1\n", root.findAll("t"));
	}

	
}
