package edu.olemiss.csci211;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

/**Maintains information about a {@link VirtualDirectory}. In addition to the information
 * in {@link VirtualFileMetaData}, this class records a list of "subfiles", meaning both
 * files and directories contained in the VirtualDirectory.
* 
*/

// TODO 75  make this class ( and other necessary classes) serializable.
public class VirtualDirectoryMetaData extends VirtualFileMetaData {
	
	private List<VirtualFileMetaData> subFiles = new LinkedQueue<VirtualFileMetaData>();
	
	/** Construct a new VirtualDirectoryMetaData object that describes the given VirtualDirectory. 
	 * In addition to the information recorded by {@link VirtualFileMetaData}, this constructor records
	 * a VirtualFileMetaData (or VirtualDirectoryMetaData) object for each subfile of the VirtualDirectory.
	 * 
	 * @param dir the VirtualDirectory to be described
	 */
	public VirtualDirectoryMetaData(VirtualDirectory dir) { 
		 
		super(dir);
		
		for(VirtualFile f: dir.getVirtualSubFiles()) {
			
			this.subFiles.add(f.createVirtualMetaData());			
		}
	}

	
	/** Return the list of Virtual MetaData objects describing subfiles of 
	 * the directory this VirtualDirectoryMetaData represents.
	 * 
	 * @return a list of VirtualFileMetaData objects
	 */
	public List<VirtualFileMetaData> getSubFileMetaDataList() {
		
		return subFiles;
	}
	
	/** Create a new {@link VirtualDirectory} from this VirtualDirectoryMetaData object. 
	 * @return a new VirtualDirectory
	 */ 
	@Override
	public VirtualFile createNewVirtualFile() {
		
		return new VirtualDirectory(this);
	}


}
