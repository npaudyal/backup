package edu.olemiss.csci211;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.NoSuchElementException;

/** A List that maintains elements in increasing order, as determined by the elements' compareTo() method.
 * 
 * @author rhodes
 *
 * @param <E> the type of element contained in the list.
 */
public class OrderedList<E extends Comparable<E>> implements List<E>{

	
	protected class Node implements Serializable {
		E data;
		Node next;
		
		public Node(E data, Node next){
			this.data=data;
			this.next=next;
		}
		
		public Node(){

		}

	}
	
	
	
	Node head = null;
	int size = 0;
	
	
	
	/**
	 * Make a new empty OrderedList.
	 */
	public OrderedList(){
		
		//redundant, really.
		this.head = null;
		this.size = 0;
	}
	
	
	

	@Override // see interface for comments.
	public void add(E e){

		Node n = new Node();
		n.data = e;
		
		if(this.head==null){
			
			n.next = null;
			head = n;								
		} else {
			
			Node prev=null;
			Node cur=head;
			
			
			while(cur!= null && ( cur.data.compareTo(e) < 0 )){
				
				prev=cur;
				cur=cur.next;
			}
			
			if(cur==null) {
				n.next=null;
				prev.next=n;
			} else {
				if(cur==head){
					n.next = head;
					head=n;
				} else {
					n.next=cur;
					prev.next=n;					
				}
			}
		}

		size++;
	}

	
	/** Remove an element from the list. If an element
	 * matching the key is found in the list, that
	 * matching element will be removed. Elements a and b match
	 * if a.compareTo(b) == 0.
	 * 
	 * @param e  The key to be matched
	 * @return the removed element
	 * @throws NoSuchElementException if no match is found
	 */
	public E remove(E e){
		
		Node prev=null;
		Node cur=head;
		
		while(cur!=null  && (cur.data.compareTo(e) < 0) ){
			
			prev=cur;
			cur=cur.next;
		}
		
		if(cur==null || cur.data.compareTo(e) != 0)
			
			throw new NoSuchElementException("No matching element found.");
		else {
		
			if(prev==null){
				head = head.next;
			} else {
				prev.next = prev.next.next;
			}
			
			size--;
			return cur.data;
		}
	}

	
	
	@Override // see interface for comments.
	public int size() {
		
		return this.size;
	}

	protected class OrderedListIterator implements PeekIterator<E>{

		Node current;
		
		OrderedListIterator(OrderedList<E> list){
			
			current = list.head;			
		}
		
		@Override
		public boolean hasNext() {
			
			return current != null;
		}

		@Override
		public E next() {
			
			E rVal = current.data;
			current = current.next;
			
			return rVal;
		}

		@Override
		public E peek() {
			
			if (hasNext())
				return current.data;
			else
				return null;
		}
	}


	@Override // see interface for comments.
	public OrderedListIterator iterator() {
		
		return new OrderedListIterator(this);
	}

	@Override // see parent for comments.
	public String toString() {
		
		StringBuilder b = new StringBuilder();
		for(E e:this) {
			
			b.append(e);
			b.append(" ");
		}
		
		return b.toString().trim();
	}



	@Override
	public void clear() {
		
		this.head = null;
	}
	

	
}
