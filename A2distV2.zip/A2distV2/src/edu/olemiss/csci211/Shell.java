package edu.olemiss.csci211;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JMenu;

import com.sun.glass.events.WindowEvent;

public class Shell {
	
	Path cwd;
	InputStream is;
	PrintStream os;
	
	
	public Shell(VirtualDirectory root, InputStream is) {
		
		this.cwd = new Path(root);
		this.is = is;
		this.os = System.out;
	}

	public Shell(VirtualDirectory root, InputStream is, PrintStream os) {
		
		this.cwd = new Path(root);
		this.is = is;
		this.os = os;
	}

	
	
	
	public void run() {
		
		
		this.os.println("Welcome to the A2 interactive shell.");
		this.os.print(">");
		Scanner s = new Scanner(this.is);
		while(s.hasNext()) {
			
			String command = s.next();
			
			switch (command) {
			
				case "open":
					String filename = s.next();
					open(filename);
					break;
				
				case "cd":
					String dirname = s.next();
					cd(dirname);			
					break;

				case "du":
					du();
					break;

				case "ls":
					ls();
					break;
					
				case "pwd":
					pwd();
					break;

				case "dir":
					String flag = s.next();
					dir(flag);
					break;
					
				case "find":
					String target = s.next();
					findAll(target);
					break;

				case "help":
					help();
					break;
				
				case "q":
				case "quit":
				case "exit":
					this.os.println("\nbye.");
					return;
					
				default:
					this.os.println("Unrecognized command: " + command);
					break;
			}
			
			this.os.print(">");
		}
		
		this.os.println("\nbye.");
		s.close();
	}
	
	
	public void open(String filename) {
		
		try {
			
			VirtualDirectory cdir = cwd.getLastDirectory();
			VirtualFile vf = cdir.findSubFile(filename);
			
			if (vf == null) {
				
				this.os.println(filename + " not found.\n");
				return;
			}
			
			VirtualFileInputStream vfis = new VirtualFileInputStream(vf);
					
			BufferedImage image = null;
			image = ImageIO.read(vfis);		
			JFrame frame = new JFrame();
				
			JLabel lblimage = new JLabel(new ImageIcon(image));
			
			frame.getContentPane().add(lblimage, BorderLayout.CENTER);
			frame.setSize(300, 400);
	
			JPanel mainPanel = new JPanel(new BorderLayout());
			mainPanel.add(lblimage);
			frame.add(mainPanel);
			frame.setVisible(true);			
			
		} catch (Exception e) {
			
			this.os.println("Error when opening file: " + filename + ". "+ e);
		}	
	}
	
	public void cd(String dirname) {
		
		//this.os.println("cd(dirname): dirname = " + dirname);
		
		if(dirname.trim().equals("..")) {
			
			int err = cwd.removeLast();
			
			if (err == Path.NO_ERR) {
				pwd();
			}else {
				this.os.println("Already at /");
			}
			return;
		}
		
		VirtualDirectory cdir = cwd.getLastDirectory();
		
		VirtualFile dest = cdir.findSubFile(dirname);
		
		if (dest == null) {
			
			this.os.println(dirname + " not found.\n");
			return;
		}
		
		
		try { 
			
			cwd.append((VirtualDirectory) dest);
			//this.os.println("append succeeded\n");
			
		} catch(ClassCastException e) {
			
			this.os.println(dirname + " is not a directory.\n");
		}
	}
	
	public void ls() {
		
		this.os.println(cwd.getLastDirectory().ls());
	}
	
	public void dir(String flag) {
		
		switch(flag) {
		
			case "-":
				this.os.println(cwd.getLastDirectory().dir());
				break;
				
			case "-s":
				this.os.println("dir -s");
				this.os.println(cwd.getLastDirectory().dirByVirtualFileSize());
				break;
				
			case "-n":
				this.os.println("dir -n");
				this.os.println(cwd.getLastDirectory().dirByVirtualFileName());
				break;
				
			default:
				this.os.println("dir: unrecognized flag "+ flag);
				break;
		}
		
	}
	

	public void pwd() {
		
		this.os.println(cwd);
		
	}

	public void findAll(String filename) {
		
		this.os.println(cwd.getLastDirectory().findAll(filename));
	}

	public void du() {
		
		this.os.println(cwd.getLastDirectory().du());
		
	}

	
	
	
	
	
	public void help() {
		
		this.os.println("Commands are: cd <dirname | ..>, dir <-, -n, -s>, ls, pwd, find <filename>, du, open <filename>.  Type 'quit' or 'exit' to exit.");
	}



}
