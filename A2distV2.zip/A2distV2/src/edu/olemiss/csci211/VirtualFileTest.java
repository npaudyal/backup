package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class VirtualFileTest {


	@Test 
	public void constructorOneShouldntThrow1() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1"}, Block.NO_CHECKSUM);
		
		VirtualFile f = new VirtualFile(fm1);
	}

	@Test 
	public void constructorOneShouldntThrow2() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1","A1UnitTestData/f2"}, Block.NO_CHECKSUM);
		
		new VirtualFile(fm1);
	}
	
	@Test 
	public void constructorOneShouldntThrow6() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		
		new VirtualFile(fm1); 
	}
	
	
	@Test (expected = IllegalArgumentException.class)
	public void constructorOneShouldThrowNULL() {
	
		new VirtualFile((VirtualFileMetaData) null);
	}
	
	
//	@Test 
//	public void constructorTwoShouldntThrow1() {
//		
//		new VirtualFile(new String [] {"A1UnitTestData/f1"});
//	}
	
	

//	@Test 
//	public void constructorTwoShouldntThrow2() {
//		
//		new VirtualFile(new String [] {"A1UnitTestData/f1","A1UnitTestData/f2"});
//	}

//	@Test 
//	public void constructorTwoShouldntThrow6() {
//		
//		new VirtualFile(new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"});
//	}
//
//	@Test (expected = IllegalArgumentException.class)
//	public void constructorTwoShouldThrowNULL() {
//	
//		new VirtualFile((String []) null);
//	}
//
//	@Test (expected = IllegalArgumentException.class)
//	public void constructorTwoShouldThrowZeroLengthNamesArray() {
//	
//		new VirtualFile(new String[0]);
//	}
//	
//	@Test (expected = IllegalArgumentException.class)
//	public void constructorTwoShouldThrowNamesArrayHasNULLelement() {
//	
//		String [] names = new String [2];
//		names[0]="A1UnitTestData/f1";
//		//names[1] is null
//		
//		new VirtualFile(names);
//	}

	@Test 
	public void constructorOneMakesValidTapeFile() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		assertTrue(t.isValid());
	}

	
//	@Test 
//	public void constructorTwoMakesValidTapeFile() {
//		
//		VirtualFile t = new VirtualFile(new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"});
//		
//		assertTrue(t.isValid());
//	}

	@Test (expected = IllegalArgumentException.class) 
	public void advanceToShouldThrowOnOutOfRange1() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		t.advanceTo(-1);
	}

	@Test (expected = IllegalArgumentException.class) 
	public void advanceToShouldThrowOnOutOfRange2() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		t.advanceTo(6);
	}

	@Test (expected = IllegalArgumentException.class) 
	public void advanceToShouldThrowOnOutOfRange3() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		t.advanceTo(7);
	}

	@Test  
	public void advanceToFirstBlock() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		IndexedFileBlock b = t.advanceTo(0);
		assertEquals("A1UnitTestData/f1", b.getFileName());
	}

	@Test  
	public void advanceToLastBlock() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		IndexedFileBlock b = t.advanceTo(5);
		assertEquals("A1UnitTestData/f6", b.getFileName());
	}
	
	@Test  
	public void advanceToMiddleBlock() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		IndexedFileBlock b = t.advanceTo(3);
		assertEquals("A1UnitTestData/f4", b.getFileName());
	}

	@Test  
	public void advanceToOneBlock() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		IndexedFileBlock b = t.advanceTo(0);
		assertEquals("A1UnitTestData/f1", b.getFileName());
	}

	@Test  
	public void advanceAdvance1() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		t.advanceTo(1);
		IndexedFileBlock b = t.advanceTo(3);
		assertEquals("A1UnitTestData/f4", b.getFileName());
	}

	@Test  
	public void advanceAdvance2() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		t.advanceTo(1);
		IndexedFileBlock b = t.advanceTo(0);
		assertEquals("A1UnitTestData/f1", b.getFileName());
	}

	@Test  
	public void advanceAdvance3() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		t.advanceTo(4);
		IndexedFileBlock b = t.advanceTo(1);
		assertEquals("A1UnitTestData/f2", b.getFileName());
	}

	@Test  
	public void advanceAdvanceAdvance() {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFile t = new VirtualFile(fm1);
		
		t.advanceTo(1);
		t.advanceTo(3);
		IndexedFileBlock b = t.advanceTo(5);
		assertEquals("A1UnitTestData/f6", b.getFileName());
	}

	
	
	
	
}
