package edu.olemiss.csci211;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class VirtualChangeSetTest { 
	
	VirtualFile f1;
	VirtualFile f2;
	
	@Before
	public void setUp() throws Exception {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFileMetaData fm2 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f8", "A1UnitTestData/f3", "A1UnitTestData/f7", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		
		this.f1 = new VirtualFile(fm1);		
		this.f2 = new VirtualFile(fm2);

	}
	

	@Test
	public void constructorShouldntThrow() {
	
		new VirtualChangeSet(f1,f2);
	}


	
	@Test
	public void applyTo() {
				
		VirtualChangeSet c1 = new VirtualChangeSet(f1,f2);
		long cs1 = f1.computeCheckSum();
		
		c1.applyTo(f1);
		
		long cs2 = f1.computeCheckSum();
		
		assertTrue(cs1 != cs2); // should be different.
		assertEquals(cs2, f2.computeCheckSum()); // should be the same.
	}


	@Test (expected = java.lang.IllegalStateException.class)
	public void apply3() {
				
		VirtualChangeSet c1 = new VirtualChangeSet(f1,f2);
		long cs1 = f1.computeCheckSum();
		
		c1.applyTo(f1);
		c1.applyTo(f1);// should throw
		
	}

	
	@Test
	public void undo() {
				
		VirtualChangeSet c1 = new VirtualChangeSet(f1,f2);
		long cs1 = f1.computeCheckSum();
		
		c1.applyTo(f1);
		c1.undo(f1);
		
		long cs2 = f1.computeCheckSum();
		
		assertEquals(cs1,cs2); // should be same.
	}

	@Test (expected = java.lang.IllegalStateException.class)
	public void undo2() {
				
		VirtualChangeSet c1 = new VirtualChangeSet(f1,f2);
		long cs1 = f1.computeCheckSum();
		
		c1.undo(f1); // should throw
	}


	
}
