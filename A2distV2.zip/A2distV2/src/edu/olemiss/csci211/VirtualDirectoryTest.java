package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.junit.Test;

public class VirtualDirectoryTest {

	@Test
	public void constructor1ShouldNOTThrow() {
		
		
		new VirtualDirectory("root");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void constructor1ShouldThrow() {
		
		new VirtualDirectory((String) null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void constructor2ShouldThrow() {
		
		new VirtualDirectory((VirtualDirectoryMetaData) null);
	}
	
	
	@Test
	public void add1() {
		
		VirtualFile vf = new VirtualFile("t1","scrap/t1");
		
		VirtualDirectory vdir = new VirtualDirectory("root");
		
		vdir.addSubFile(vf);
		
		String result = vdir.ls();
		
		assertEquals("t1", result);
	}

	@Test
	public void add2() {
		
		VirtualFile vf1 = new VirtualFile("t1","scrap/t1");
		VirtualFile vf2 = new VirtualFile("t2","scrap/t2");
		
		VirtualDirectory vdir = new VirtualDirectory("root");
		
		vdir.addSubFile(vf1);
		vdir.addSubFile(vf2);
		
		String result = vdir.ls();
		
		assertEquals("t1 t2", result);
	}

	@Test
	public void add3() {
		
		VirtualFile vf1 = new VirtualFile("t1","scrap/t1");
		VirtualFile vf2 = new VirtualFile("t2","scrap/t2");
		VirtualFile vf3 = new VirtualFile("t3","scrap/t3");
		
		VirtualDirectory vdir = new VirtualDirectory("/", "scrap/root");
		
		vdir.addSubFile(vf1);
		vdir.addSubFile(vf2);
		vdir.addSubFile(vf3);
		
		//System.out.println(vdir.dir());
		
		String result = vdir.ls();
		
		assertEquals("t1 t2 t3", result); 
	}

	
	@Test
	public void addDir() {
			
		VirtualDirectory root = new VirtualDirectory("root", "scrap/root");
		
		VirtualDirectory vd1 = new VirtualDirectory("d1", "scrap/d1");
	
		root.addSubFile(vd1);
		
		//System.out.println(root.dir());
		
		String result = root.ls();
		
		assertEquals("d1", result);
	}

	
	@Test
	public void addDir2() {
		
		VirtualDirectory vd1 = new VirtualDirectory("d1", "scrap/d1");
		VirtualFile vf2 = new VirtualFile("t2", "scrap/t2");
		VirtualFile vd3 = new VirtualDirectory("d3", "scrap/d3");
		
		VirtualDirectory vdir = new VirtualDirectory("root", "scrap/root");
		
		vdir.addSubFile(vd1);
		vdir.addSubFile(vf2);
		vdir.addSubFile(vd3);
		
		//System.out.println(vdir.dir());
		
		String result = vdir.ls();
		
		assertEquals("d1 t2 d3", result);
	}

	
	@Test
	public void serDeEmptyDirShouldNOTthrow() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		root.writeToFile();
		
		root=null;
				
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
	}

	
	@Test
	public void serDe1() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		// A simple example of an image file.
		VirtualFile hamster = new VirtualFile("hamster", "scrap/hamster");
		hamster.importFile("images/hamster.jpg");
		root.addSubFile(hamster);

		root.writeToFile();
		root = null;
		
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("hamster", newdir.ls());
	}

	@Test
	public void serDe2() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		
		VirtualFile hamster = new VirtualFile("hamster", "scrap/hamster");
		//hamster.importFile("images/hamster.jpg");
		root.addSubFile(hamster);

		root.writeToFile();
		root = null;
		
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("hamster", newdir.ls());
	}
	
	@Test
	public void serDe3() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory home = new VirtualDirectory("home", "scrap/home");
		
		root.addSubFile(home);
		
		root.writeToFile();
		root = null;
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("home", newdir.ls());
		//System.out.println(newdir.dir());
	}

	@Test
	public void serDe4() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory home = new VirtualDirectory("home", "scrap/home");
		
		VirtualFile hamster = new VirtualFile("hamster", "scrap/hamster");
		//hamster.importFile("images/hamster.jpg");

		root.addSubFile(hamster);
		
		
		root.addSubFile(home);
		
		root.writeToFile();
		root = null;
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("hamster home", newdir.ls());
		//System.out.println(newdir.dir());
	}

	

	

}
