
package edu.olemiss.csci211;

import java.io.*;
import java.util.Arrays;
import java.util.Random;
import java.util.zip.CRC32;


/** A Block is a series of bytes with an associated checksum value. Checksums are computed using
 * Java's {@link CRC32} class. A Block is considered valid if the checksum data member matches the value
 * computed by the {@link CRC32} class. Only one constructor allows the creation of invalid blocks, useful 
 * for testing. 
 * 
 * Child classes of Block may also produce invalid blocks, perhaps due to errors reading block 
 * data from file or over a network connection. The checksum value is key to detecting these kind
 * errors. 
 * 
 * @author rhodes
 *
 */
public class Block implements Checkable, Writeable{
	
	/** Used to indicate that a real checksum value has not been computed or given.*/
	public final static int NO_CHECKSUM = -1; // -1 is not a CRC32 value, so if we see this number during
											  // debugging, we know it didn't come from computeCheckSum()
	
	public final static int DEFAULT_BLOCK_SIZE = 512;
	
	byte [] data = null;
	 
	long checksum = NO_CHECKSUM; 
	
	/** Construct a valid Block with data length DEFAULT_BLOCK_SIZE, expressed in bytes. Block byte 
	 * values will all be 0. 
	 * 
	 */
	public Block() {
		
		this(new byte[DEFAULT_BLOCK_SIZE]);
	}
	
	
	/** Construct a valid Block of the given size, expressed in bytes. Block byte 
	 * values will be randomly generated. 
	 * 
	 * @param size of data in bytes
	 * @throws IllegalArgumentException if size &le; 0
	 */
	public Block(int size) { // constructor 1
		
		if (size <= 0 )
			throw new IllegalArgumentException("size is <= 0");
		
		this.data = new byte[size];
		
		new Random().nextBytes(this.data);
		
		this.checksum = this.computeCheckSum();
	}
	
	/** Construct a valid Block with the given bytes.
	 * 
	 * @param bytes an array of arbitrary bytes.
	 */
	public Block(byte [] bytes) { // constructor 2

		if (bytes == null )
			throw new IllegalArgumentException("byte array is null.");

		if (bytes.length == 0)
			throw new IllegalArgumentException("byte array is zero length.");

		this.data = bytes;
		
		this.checksum = this.computeCheckSum();
	}
	
	/** Construct a block with the given bytes and checksum.
	 *  The block will only be valid if the checksum matches
	 *  the data.
	 *  @param checksum a provided checksum value that will match the data unless there has been a transmission or read error.
	 *  @param bytes an array of arbitrary data bytes.
	 */
	public Block(long checksum, byte [] bytes) { // constructor 3

		if (bytes == null )
			throw new IllegalArgumentException("byte array is null.");

		if (bytes.length == 0)
			throw new IllegalArgumentException("byte array is zero length.");

		this.data = bytes;
		this.checksum = checksum;
	}

	/** This "copy constructor" makes a deep copy of the given block. This block
	 * will NOT share a reference to the same data array as the given block, but instead
	 * has its own separate copy of the array.
	 * 
	 * @param b the block to copy.
	 * @throws IllegalArgumentException if b is null.
	 */
	public Block(Block b) {  // constructor 4
		
		if (b == null)
			throw new IllegalArgumentException("Copy constructor: argument is null.");
		
		this.data = Arrays.copyOf(b.data, b.data.length);
		this.checksum = b.checksum;
	}

	/** Set the contents of this Block to be a deep copy of the given block. This block
	 * will NOT share a reference to the same data array as the given block.
	 *  
	 * @param newblock the block to copy.
	 */
	public void assign(Block newblock) {

		this.data = Arrays.copyOf(newblock.data, newblock.data.length);
		this.checksum = newblock.checksum;
	}
	
	
	/** Write the Block to the given stream.
	 *  The stream should already be open for writing.
	 * @param dos an open DataOutputStream
	 * @throws IllegalArgumentException if an IO error is encountered.
	 */
	public void write(DataOutputStream dos) {
		
		try {
			dos.writeLong(this.computeCheckSum());
			dos.writeInt(this.data.length);
			dos.write(data);
			
		} catch(IOException e) {
			throw new IllegalArgumentException("Error writing to stream.");
		}
	}

	/** Write the Block to the given stream, writing only the specified number of bytes
	 * to the data portion of the block file. The stream should already be open for writing. 
	 * The written block file will be identical to the results written by a block with
	 * a data array that is numBytes long: the size and checkSum fields will look the same. 
	 * @param dos an open DataOutputStream
	 * @param numBytes the number of data bytes to write.
	 * @throws IllegalArgumentException if an IO error is encountered.
	 */
	public void write(DataOutputStream dos, int numBytes) {
		
		try {
			dos.writeLong(this.computeCheckSum(numBytes));
			dos.writeInt(numBytes);
			dos.write(data, 0, numBytes);
			
		} catch(IOException e) {
			throw new IllegalArgumentException("Error writing to stream.");
		}
	}

	
	
	
	/** Write the Block to a file with the given name. If the file already
	 * exists, it will be overwritten. The file stream will be closed when
	 * writing is complete.
	 * @param filename the name of the file to write to.
	 * @throws IllegalArgumentException if an IO error is encountered.
	 */
	public void write(String filename) {
		
		try {
			FileOutputStream fos = new FileOutputStream(filename);
			DataOutputStream dos = new DataOutputStream(fos);
			
			write(dos);

			dos.close();
		} catch(IOException e) {
		
			throw new IllegalArgumentException("Error opening or writing to file:" + filename);
		}
	}

	
	/** Write the Block to a file with the given name, writing only the specified 
	 * number of data bytes. If the file already
	 * exists, it will be overwritten. The file stream will be closed when
	 * writing is complete.
	 * @param filename the name of the file to write to.
	 * @param numBytes the number  of data bytes to write
	 * @throws IllegalArgumentException if an IO error is encountered.
	 */
	public void write(String filename, int numBytes) {
		
		try {
			FileOutputStream fos = new FileOutputStream(filename);
			DataOutputStream dos = new DataOutputStream(fos);
			
			write(dos, numBytes);

			dos.close();
		} catch(IOException e) {
			throw new IllegalArgumentException("Error opening or writing to file.");
		}
	}

	
	
	/** Compute a checksum from the data array using Java's CRC32 class.
	 * 
	 * @return The CRC32 checksum for this Block's data.
	 */
	public long computeCheckSum() {
		
		CRC32 crc = new CRC32();
		
		crc.update(data);
		return crc.getValue();
	}
	
	/** Compute a checksum from the data array using Java's CRC32 class. Only the
	 * first numBytes of the data array are considered.
	 * 
	 * @param numBytes the number of bytes from the data array to give to {@link CRC32#update}
	 * @return The CRC32 checksum for this Block's data.
	 */
	public long computeCheckSum(int numBytes) {
		
		CRC32 crc = new CRC32();
		
		crc.update(data, 0, numBytes);
		return crc.getValue();
	}
	
	
	
	/** Return the size of the Block.
	 * 
	 * @return the number of bytes in the Block's data.
	 */
	public int size() {
		
		return this.data.length;
	}
	
	/** Return a reference to this block's data.
	 * 
	 * @return a byte[] containing the Block's data.
	 */
	public byte [] data() {
		
		return this.data;
	}

	@Override // see interface or parent
	public long getCheckSumField() {
		
		return this.checksum;
	}

	@Override // see interface or parent
	public void resetCheckSum() {
		
		this.checksum=this.computeCheckSum();
		
	}
	
	

}
