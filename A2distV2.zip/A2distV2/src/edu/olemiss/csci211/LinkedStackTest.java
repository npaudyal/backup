package edu.olemiss.csci211;

import static org.junit.Assert.*;

import org.junit.Test;

public class LinkedStackTest {

	@Test
	public void constructorDoesntThrow() {
		
		new LinkedStack<Integer>();
	}

	@Test(expected = java.util.NoSuchElementException.class)
	public void emptyPop() {
		
		LinkedStack<Integer> s=new LinkedStack<Integer>();
		
		assertEquals(null, s.pop());
	}

	@Test
	public void pushpop() {
		
		LinkedStack<Integer> s=new LinkedStack<Integer>();
		
		s.push(12);
		
		assertEquals(new Integer(12), s.pop());
	}
	
	@Test(expected = java.util.NoSuchElementException.class)
	public void pushpoppop() {
		
		LinkedStack<Integer> s=new LinkedStack<Integer>();
		
		s.push(12);
		s.pop();
		
		assertEquals(null, s.pop());
	}

	
	@Test
	public void pushpushpoppop() {
		
		LinkedStack<Integer> s=new LinkedStack<Integer>();
		
		s.push(12);
		s.push(9);
		
		s.pop();
		
		assertEquals(new Integer(12), s.pop());
	}

	@Test
	public void pushpoppushpop() {
		
		LinkedStack<Integer> s=new LinkedStack<Integer>();
		
		s.push(12);
		s.pop();
		s.push(9);
		
		assertEquals(new Integer(9), s.pop());
	}
	
	

}
