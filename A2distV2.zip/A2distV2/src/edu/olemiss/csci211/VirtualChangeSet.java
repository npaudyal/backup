package edu.olemiss.csci211;

import java.util.Iterator;

/** A VirtualChangeSet is a List of {@link IndexedFileBlock}s that represents the difference between two 
 * versions of a {@link VirtualFile}. It can be used as a kind of incremental backup. This list of blocks
 * only contains the new blocks that must replace old blocks in order to produce a new version from the old version of
 * the VirtualTapeFile. 
 * <p>
 * We'll assume that the two versions of the virtual file have the same number of blocks, which simplifies
 * things considerably. We can just use the index of the IndexedFileBlocks to indicate which blocks in the old
 * version of the file must be replaced. 
 * <p>
 * In addition, a VirtualChangeSet can be undone after being applied, restoring the VirtualTapeFile to its original state.
 * 
 * @author rhodes
 */
public class VirtualChangeSet {	
	
	List<IndexedFileBlock> newBlocks = new OrderedList<IndexedFileBlock>();
	List<IndexedFileBlock> originalblocks = new OrderedList<IndexedFileBlock>();
		
	boolean applied = false;
	
	/** Construct a new VirtualChangeSet by comparing the blocks in the given files. 
	 * If this new VirtualChangeSet were to be applied to the original VirtualTapeFile, the 
	 * result would be identical to newFile .
	 * <p>
	 * We'll assume that the two parameter files have the same number of blocks, which simplifies
	 * things considerably.
	 * 
	 * @param original the original version of the file
	 * @param newFile the new version of the file
	 */
	public VirtualChangeSet(VirtualFile original, VirtualFile newFile) {
		
		List<IndexedFileBlock> revisedBlocks = newFile.getBlocks();
		Iterator<IndexedFileBlock> newBlockIterator = revisedBlocks.iterator();
		IndexedFileBlock n;
		
		n = newBlockIterator.next();
		for(IndexedFileBlock o:original.getBlocks()) {
			
			if(o.computeCheckSum() != n.computeCheckSum()){
				
				newBlocks.add(n);
			}
			
			if (newBlockIterator.hasNext())
				n = newBlockIterator.next();
		}
	}
	
	/**  Apply this VirtualChangeSet to the given VirtualTapeFile, replacing any block of the VirtualTapeFile with
	 * an index matching a block in this changeset. Replaced blocks are still kept internally, allowing {@link #undo(VirtualFile)}
	 * to undo the effects of apply. 
	 * 
	 * @param f the file to be updated with new blocks.
	 * @throws IllegalStateException if this VirtualChangeSet has already been applied since construction, or since
	 * undo() was called.

	 */
	public void applyTo(VirtualFile f){
	
		if (applied)
			throw new IllegalStateException();

		this.originalblocks.clear();
		
		for(IndexedFileBlock change:newBlocks) {
			
			IndexedFileBlock b = f.advanceTo(change.getIndex());
			this.originalblocks.add(new IndexedFileBlock(b));			
			b.assign(change);
		}
		
		f.resetCheckSum();
		applied = true;
	}
	
	/** Undo the last application of this VirtualChangeSet to the given VirtualTapeFile. The VirtualTapeFile will
	 * be restored to the state it had before this VirtualChangeSet was applied. If the  VirtualTapeFile never had
	 * this VirtualChangeSet applied to it, results are undefined. 
	 * 
	 * @param f the VirtualTapeFile to be modified.
	 * @throws IllegalStateException if this VirtualChangeSet has not been applied since construction, or since the
	 * last call to this method.
	 */	
	public void undo(VirtualFile f){
	
		
		if (!applied)
			throw new IllegalStateException();
		
		this.newBlocks.clear();
		
		for(IndexedFileBlock original:originalblocks) {
			
			IndexedFileBlock b = f.advanceTo(original.getIndex());
			this.newBlocks.add(new IndexedFileBlock(b));
			b.assign(original);
		}
		
		f.resetCheckSum();
		applied = false;
	}
}
