package edu.olemiss.csci211;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.zip.CRC32;


/** Represents a virtual file stream as a sequence of 
 * {@link IndexedFileBlock}s read from REAL files. 
 * 
 * @author rhodes
 *
 */

public class VirtualFile  implements Checkable, Iterable<IndexedFileBlock>, Comparable<VirtualFile>{

	private long checksum;
	private String virtualFileName;
	
	// These next two help makeNewFileName() to make unique blockFile names.  e.g.  cat_0000000, cat_0000001, etc.
	private String blockFileBaseName; // prefix for blockFile names.	 e.g. cat
	private int nextBlockIndex;       // numeric suffix blockFile names. e.g.  0000001
	
	private List<IndexedFileBlock> blocks = new LinkedQueue<IndexedFileBlock>();
	private Iterator<IndexedFileBlock> blockIterator = null;
	private IndexedFileBlock currentBlock;
			
	
	/** Construct a new VirtualFile from the given VirtualFileMetaData parameter.
	 * Names of (REAL) block files and the virtual file checksum will be read from
	 * the parameter. If the checksum read from the  VirtualFileMetaData is not
	 * valid, the checksum field of this VirtualTapeFile will be recomputed from
	 * the blocks.
	 * 
	 * @param fm the VirtualFileMetaData object. 
	 * @throws IllegalArgumentException if the parameter is null
	 */
	public VirtualFile(VirtualFileMetaData fm ) { //constructor 1
		
		if(fm == null) 
			throw new IllegalArgumentException("FileMetaData argument was null.");
		
		this.checksum = fm.getCheckSum();
		
		this.nextBlockIndex=0;
		for(String name:fm.getBlockFileNames()) {
			
			blocks.add(new IndexedFileBlock(name, this.nextBlockIndex++)); 
		}
		
		this.blockFileBaseName = fm.blockFileBaseName();
		this.virtualFileName = fm.virtualFileName();
		
		if(this.checksum == Block.NO_CHECKSUM)
			this.resetCheckSum();
	} 
	
	
	
	
	
	/** Constructs a lightweight VirtualFile using the given name as the virtualFileName. 
	 * This is useful for compareTo(), so we can "wrap" the filename with a VirtualFile object.
	 * 
	 * @param name the virtualFileName of the new VirtualFile
	 * @param bogus ignored
	 */
	protected VirtualFile(String name, boolean bogus) {
		
		this.virtualFileName = name;
	}
	
	
	/** Constructs a VirtualFile with the given name. Existing file blocks (if any) are
	 * expected to begin with the given blockFileBaseName, with a numeric suffix.
	 * 
	 * @param virtualFileName the virtualFileName of the new VirtualFile
	 * @param blockFileBaseName the prefix used when automatically adding new blocks.
	 */
	public VirtualFile(String virtualFileName, String blockFileBaseName) {
		
		if (virtualFileName == null )
			throw new IllegalArgumentException("virtualFileName is null.");
		
		this.virtualFileName = virtualFileName;
		this.blockFileBaseName = blockFileBaseName;
		
		if (this.blockFileBaseName == null )
			this.blockFileBaseName = this.virtualFileName;


		boolean done = false;
		this.nextBlockIndex=0;
		while(!done) {
			
			String filename = makeNewFileName();
			
			try {
				blocks.add(new IndexedFileBlock(filename, this.nextBlockIndex));
				this.nextBlockIndex++;
			} catch(IllegalArgumentException e) {
				
				done=true;
			}
		}
		
		// Let's ensure there's at least one block.
		if(this.nextBlockIndex == 0) {
			
			this.addNewBlock();
		}
		
		this.resetCheckSum();
	}

	/** Construct a virtual file with the given virtual name. The blockfilebasename is
	 * set to "blocks/"+virtualFileName, so the blocks directory is assumed to exist.
	 * @param virtualFileName the name of the virtual file
	 */
	public VirtualFile(String virtualFileName) {
	
		this(virtualFileName, "blocks/"+virtualFileName);
	}

	/** Import data from a REAL file with the given name into this VirtualFile.
	 * 
	 * @param filename the name of the REAL file.
	 * @return a reference to this VirtualFile. (useful for chaining method().calls()
	 */
	public VirtualFile importFile(String filename) {

		//TODO 100
		
		// make a VirtualFileOutputStream that writes to this VirtualFile.
		// make a DataInputStream that reads from a file with the given filename argument.
		
		// read values from one stream, writing to the other, until a -1 is read from the 
		// input stream.
		
		// close the streams.
		
		return this;
	}
	
	
	

	
	/** Construct and return a new  VirtualFileMetaData instance representing this
	 * VirtualFile.
	 * @return a new VirtualFileMetaData object.
	 */
	public VirtualFileMetaData createVirtualMetaData() {
		
		return new VirtualFileMetaData(this);
	}
	
	/** 
	 * Compute a checksum by iterating through the blocks of this virtual file,
	 * calling {@link CRC32#update} with the data for each block. The result is
	 * a checksum that applies to the whole virtual file.
	 * @see CRC32
	 */
	@Override  // see interface or parent
	public long computeCheckSum() {
		
		CRC32 crc = new CRC32();
		
		for(Block b:blocks) {
			
			crc.update(b.data);
		}
		
		return crc.getValue();
	}

	
	/** Compute a checksum from a data array using Java's CRC32 class. Only the first
	 * numBytes bytes of the data array are considered.
	 * 
	 * @return The CRC32 checksum for the data.
	 */
	public long computeCheckSum(int numBytes) {
		CRC32 crc = new CRC32();
		
		int numBytesChecked = 0;
		for(Block b:blocks) {
			
			int bytesRemaining = numBytes - numBytesChecked;
			
			int bytesToCheck = (bytesRemaining > b.data.length) ? b.data.length : bytesRemaining;
			
			crc.update(b.data, 0, bytesToCheck - 1);
			numBytesChecked += bytesToCheck;
			
			//crc.update(b.data);
		}
		
		return crc.getValue();
	}

	
	@Override  // see interface or parent
	public void resetCheckSum() {
		
		this.checksum = this.computeCheckSum();
	}
	


	@Override  // see interface or parent
	public long getCheckSumField() {
		
		return this.checksum;
	}

	
	/** Return a List of {@link IndexedFileBlock}s that make up the
	 * contents of this VirtualTapeFile
	 * 
	 * @return the list of blocks
	 */
	List<IndexedFileBlock> getBlocks() {
		
		return this.blocks;
	}

	/** Return an array of Strings holding the filenames of all the blocks
	 * in this VirtualFile.
	 * 
	 * @return the array of block names
	 */
	String [] getBlockFileNames() {
		
		String [] names = new String[this.blocks.size()];
		
		int i = 0;
		for(IndexedFileBlock block: this.blocks) {
			
			names[i++] = block.getFileName();
		}
		
		return names;
	}

	
	/** Return the number of blocks  that make up the
	 * contents of this VirtualFile
	 * 
	 * @return the number of blocks
	 */
	int getNumBlocks() {
		
		return this.blocks.size();
	}
	

	/** Advance our position in the file to the given blocknumber, and return the IndexedFileBlock found
	 * at that position.
	 * @param blockNumber the block to advance to.
	 * @return the IndexedFileBlock found at the given blocknumber.
	 * @throws IllegalArgumentException if the given blocknumber is &lt; 0 or &ge; number of blocks.
	 */
	public IndexedFileBlock advanceTo(int blockNumber) {
		
		if (blockNumber < 0 || blockNumber >= blocks.size()) {
			
			throw new IllegalArgumentException("block number out of range.");
		}
		
		if (this.blockIterator == null || !this.blockIterator.hasNext() || (this.currentBlock != null && this.currentBlock.getIndex() > blockNumber)) {
			
			
			this.blockIterator = this.blocks.iterator();
			this.currentBlock = null;
		}
		
		
		while(this.blockIterator.hasNext()) {
			
			this.currentBlock = this.blockIterator.next();
			
			if (this.currentBlock.getIndex() == blockNumber) {
				return this.currentBlock;
			}	
		}
		
		assert(false);
		return null; // unreachable, right?
	}



	@Override  // see interface or parent
	public Iterator<IndexedFileBlock> iterator() {

		return this.blocks.iterator();
	}

	/** Close this file. 
	 * Currently, this method just calls {@link flush}
	 */
	public void close() {
		
		this.flush();
	}
	
	/** Tells each Block in this VirtualFile to write
	 * itself to disk. 
	 */
	public void flush() {
		
		for(IndexedFileBlock b: this.blocks) {
			
			b.write();
		}
	}


	/** Return the name of this VirtualFile.
	 * 
	 * @return a string containing the filename. 
	 */
	public String virtualFileName() {
		
		return this.virtualFileName ;
	};

	
	
	/** Return the prefix used for creating new block files.
	 * 
	 * @return a string containing the prefix. 
	 */
	public String blockFileBaseName() {
		
		return this.blockFileBaseName ;
	};

	
	
	/** Return the total size of this VirtualFile in bytes.
	 *  
	 * 
	 * @return the size 
	 */
	public long size() {
		
		long size=0;
		for(Block b: blocks) {
			
			size += b.size();
		}
		
		return size;
	}
	
	
	/** If the given target string matches this object's virtual file name,
	 * then return a string describing the path to this file. Otherwise, return the empty string.
	 *  This method is meant to be overridden by child classes as necessary.
	 * 
	 * @param pathToThisFile a string representing a path to this file.
	 * @param target the filename to be matched
	 * 
	 * @return the path to this file, represented as a string, or ""
	 */
	protected String find(String pathToThisFile, String target) {
		
		if(target.equals(this.virtualFileName))
		
			return String.format("%s\ttype:%s\tbytes on disk:%d\tblocks:%d\n",pathToThisFile, this.typeString(), this.size(), this.blocks.size());
		else
			return "";
	}

	/** Returns the size of this file in bytes. 
	 * Currently, this is the same value returned by size() 
	 * 
	 * @return the size of this file in bytes.
	 */
	public long du() {
		
		// TODO 85
		// nothing to do. I just want you to see that this is here, and that it
		// is helpful for VirtualDirectory.du().
		return this.size();		
	}


	/** Compare two VirtualFiles by filename.
	 * 
	 * @return a negative, 0, or positive number indicating the outcome of the comparison. 
	 */
	@Override
	public int compareTo(VirtualFile file) {
		
		return this.virtualFileName.compareTo(file.virtualFileName()) ;
	}
	

	@Override
	public boolean equals(Object vfile) {
		
		return this.compareTo((VirtualFile) vfile) == 0;
	}

	
	
	@Override
	public String toString() {
		
		return String.format("name:%s\ttype:%s\tbytes on disk:%d\tblocks:%d\n",this.virtualFileName, this.typeString(), this.size(), this.blocks.size());
	}
	
	/** Returns a brief string indicating the type of file. This method returns "file",
	 * while child classes (e.g. VirtualDirectory) return something different.
	 * @return "file"
	 */
	public String typeString() {
		
		return "file";
	}
	
	
	
	/** Add a new Block to this VirtualFile's list of blocks.
	 * 
	 * @return a reference to the newly added block.
	 */
	IndexedFileBlock addNewBlock() {
		
		String newBlockFileName = makeNewFileName();
		
		new Block().write(newBlockFileName);
		
		IndexedFileBlock newBlock = new IndexedFileBlock(newBlockFileName, this.nextBlockIndex++);
		
		this.blocks.add(newBlock);
		
		return newBlock;
	}

	/** Helper method that makes new filenames for block files using the {@link blockFileBaseName} and {@link nextBlockIndex} data members.
	 * 
	 * @return a new block file name.
	 */
	private String makeNewFileName() {
		
		if (blockFileBaseName == null || blockFileBaseName.equals(""))
			throw new IllegalStateException("blockFileBaseName is null or empty.");
		
		return String.format("%s_%07d", blockFileBaseName, this.nextBlockIndex);
	}
}
