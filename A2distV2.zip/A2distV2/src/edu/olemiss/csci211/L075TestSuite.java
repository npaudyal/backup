package edu.olemiss.csci211;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;
import org.junit.runners.Suite;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


@RunWith(Suite.class)
@SuiteClasses({ L075Tests.class, PathTest.class})  // Don't forget the Path class


public class L075TestSuite {

	// This testsuite runs L075Tests and PathTest
}
