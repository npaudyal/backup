/**
 * 
 */
package edu.olemiss.csci211;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author rhodes
 *
 */
public class IndexedFileBlockTest {

//	/**
//	 * @throws java.lang.Exception
//	 */
//	@Before
//	public void setUp() throws Exception {
//	}
//
//	/**
//	 * @throws java.lang.Exception
//	 */
//	@After
//	public void tearDown() throws Exception {
//	}

	@Test
	public void constructorTestGoodFileValid() {
		// "GoodFile" is a valid file with 512 data bytes
		IndexedFileBlock fb = new IndexedFileBlock("A1UnitTestData/GoodFile", 12);
				
		assertTrue(fb.isValid());
	}

	@Test
	public void constructorTestGoodFileIndex() {
		// "GoodFile" is a valid file with 512 data bytes
		IndexedFileBlock fb = new IndexedFileBlock("A1UnitTestData/GoodFile", 12);
				
		assertEquals(12, fb.getIndex());
	}
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructorTestMissingFile() {
		
		// file doesn't exist
		new IndexedFileBlock("A1UnitTestData/missingFile", 10);	
	}
	
	@Test
	public void compareTo1() {
		
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock("A1UnitTestData/tiny", 101);
		
		assertTrue(a.compareTo(b) < 0);
	}

	@Test
	public void compareTo2() {
		
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock("A1UnitTestData/tiny", 101);
		
		assertTrue(b.compareTo(a) > 0);
	}

	@Test
	public void compareTo3() {
		
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock("A1UnitTestData/f1", 100);
		
		assertTrue(b.compareTo(a) == 0);
	}

	@Test
	public void copyConstructorIndex() {
				
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock(a);
		
		assertEquals(a.getIndex(), b.getIndex());
	}

	@Test
	public void copyConstructorDeepCopy() {
				
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock(a);
		
		a.data[0] = 42; // changed the data array.
		
		assertNotEquals(a.computeCheckSum(), b.computeCheckSum()); // these shouldn't be the same, because we changed the data.
	}

	@Test
	public void copyConstructorChecksum() {
				
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock(a);
		
		assertEquals(a.isValid(), b.isValid()); // if these are the same, the checksum field is the same.
	}

	@Test
	public void assignIndex() {
				
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock("A1UnitTestData/f1", 100);
		
		a.assign(b);
		
		assertEquals(a.getIndex(), b.getIndex());
	}

	@Test
	public void assignData1() {
				
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock("A1UnitTestData/f1", 100);
		
		a.assign(b);
		
		assertEquals(a.computeCheckSum(), b.computeCheckSum()); // if these are the same, the data's the same.
	}

	@Test
	public void assignDataDeepCopy() {
				
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock("A1UnitTestData/f1", 100);
		
		a.assign(b);
		
		a.data[0] = 42; // changed the data array.
		
		assertNotEquals(a.computeCheckSum(), b.computeCheckSum()); // these shouldn't be the same, because we changed the data.
	}

	@Test
	public void assignChecksum() {
				
		IndexedFileBlock a = new IndexedFileBlock("A1UnitTestData/tiny", 100);	
		IndexedFileBlock b = new IndexedFileBlock("A1UnitTestData/f1", 100);
		
		a.assign(b);
		
		assertEquals(a.isValid(), b.isValid()); // if these are the same, the checksum field is the same.
	}


	


	
}
