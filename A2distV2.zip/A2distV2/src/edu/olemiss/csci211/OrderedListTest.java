package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.util.NoSuchElementException;
import java.io.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OrderedListTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void constructorShouldntThrow() {
	
		new OrderedList<Integer>();
	}
	
	@Test
	public void addShouldntThrow() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(5);
	}

	@Test
	public void add() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(5);
		
		assertEquals("5", l.toString());
	}

	
	@Test
	public void addAdd1() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(5);
		l.add(6);
		
		assertEquals("5 6", l.toString());
	}


	@Test
	public void addAddAdd1() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(8);
		l.add(6);
		l.add(1);
		
		assertEquals("1 6 8", l.toString());
	}

	@Test
	public void addAddAdd2() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		l.add(8);
		l.add(6);
		l.add(9);
		
		assertEquals("6 8 9", l.toString());
	}

	
	
	@Test
	public void addAddRemove1() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(8);
		l.add(6);
		Integer i = l.remove(8);
		
		assertEquals(new Integer(8), i);
		assertEquals("6", l.toString());
	}

	@Test
	public void addAddRemove2() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(8);
		l.add(6);
		Integer i = l.remove(6);
		
		assertEquals(new Integer(6), i);
		assertEquals("8", l.toString());
	}
	
	@Test (expected = NoSuchElementException.class)
	public void addAddRemoveShouldThrow() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(8);
		l.add(6);
		l.add(12);
		
		Integer i = l.remove(4); // should throw
	}

	@Test (expected = NoSuchElementException.class)
	public void removeShouldThrow() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		Integer i = l.remove(4); // should throw
	}

	

	@SuppressWarnings("unused")
	@Test
	public void iteratorShouldntThrow1() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		for(Integer i:l) {
			
		}
	}
 
	@SuppressWarnings("unused")
	@Test
	public void iteratorShouldntThrow2() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(8);
		
		for(Integer i:l) {
			
			
		}
	}

	@Test
	public void iteratorCorrect1() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		l.add(1);
		l.add(2);
		l.add(3);
		
		StringBuilder b = new StringBuilder();
		for(Integer i:l) {
			
			b.append(i);
		} 
		
		assertEquals("123", b.toString());
	}

	@Test
	public void iteratorCorrect2() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		StringBuilder b = new StringBuilder();
		for(Integer i:l) {
			
			b.append(i);
		}
		
		assertEquals("", b.toString());
	}

	@Test
	public void iteratorHasNextFalseOnEmpty() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		PeekIterator<Integer> i = l.iterator();
		assertFalse(i.hasNext());
	}

	@Test
	public void iteratorPeekReturnsNullOnEmpty() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		PeekIterator<Integer> i = l.iterator();
		assertEquals(null, i.peek());
	}

	@Test
	public void iteratorPeekNotNullOn1Element() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		l.add(1);
		
		PeekIterator<Integer> i = l.iterator();
		assertTrue(null != i.peek());
	}

	@Test
	public void iteratorPeekValue1() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		l.add(0);
		
		PeekIterator<Integer> i = l.iterator();
		assertEquals(new Integer(0), i.peek());
	}

	@Test
	public void iteratorPeekValue2() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		l.add(0);
		l.add(1);
		
		PeekIterator<Integer> i = l.iterator();
		
		assertEquals(new Integer(0), i.peek());
		
		i.next();	
		
		assertEquals(new Integer(1), i.peek());
		
		i.next();
		
		assertEquals(null, i.peek());
	}

	@Test
	public void iteratorPeekValue3() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		l.add(0);
		l.add(1);
		l.add(2);
		
		PeekIterator<Integer> i = l.iterator();
		
		assertEquals(new Integer(0), i.peek());
		
		assertEquals(new Integer(0), i.next());	
		
		assertEquals(new Integer(1), i.peek());
		
		assertEquals(new Integer(1), i.next());
		
		assertEquals(new Integer(2), i.peek());

		assertEquals(new Integer(2), i.next());

		assertEquals(null, i.peek());
	}

	@Test
	public void iteratorPeekValue4() {
	
		OrderedList<Integer> l = new OrderedList<Integer>();
		
		l.add(0);
		l.add(1);
		l.add(2);
		
		PeekIterator<Integer> i = l.iterator();
			
		assertEquals(new Integer(0), i.next());	
		assertEquals(new Integer(1), i.next());
		
		assertTrue(i.hasNext());
		assertEquals(new Integer(2), i.next());
		assertFalse(i.hasNext());
		
		assertEquals(null, i.peek());
	}

//	@Test
//	public void serializationWriteObjectDoesntThrow() {
//		
//		OrderedList<Integer> l = new OrderedList<Integer>();
//		
//		l.add(0);
//		l.add(1);
//		l.add(2);
//		
//		try {
//	        // Saving of object in a file 
//	        FileOutputStream fos = new FileOutputStream("UnitTestData/serialize1"); 
//	        ObjectOutputStream oos = new ObjectOutputStream(fos); 
//	
//	        oos.writeObject(l);
//			oos.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}

//	@Test
//	public void serializationReadObject() {
//		
//		OrderedList<Integer> l = new OrderedList<Integer>();
//		
//		l.add(0);
//		l.add(1);
//		l.add(2);
//		
//		try {
//	        // Saving of object in a file 
//	        FileOutputStream fos = new FileOutputStream("UnitTestData/serialize2"); 
//	        ObjectOutputStream oos = new ObjectOutputStream(fos); 
//	
//	        oos.writeObject(l);
//			oos.close();
//			
//			FileInputStream fis = new FileInputStream("UnitTestData/serialize2");
//			ObjectInputStream ois = new ObjectInputStream(fis);
//			
//			OrderedList<Integer> l2 = (OrderedList<Integer>) ois.readObject();
//			
//			assertEquals("0 1 2",l2.toString());
//			
//			System.out.println(l);
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}

	
	

}
