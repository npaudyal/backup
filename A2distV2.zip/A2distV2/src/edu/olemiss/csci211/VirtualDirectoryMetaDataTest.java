package edu.olemiss.csci211;

import static org.junit.Assert.*;

import org.junit.Test;

public class VirtualDirectoryMetaDataTest {

	@Test
	public void constructorShouldNOTthrow() {
		
		VirtualDirectory dir = new VirtualDirectory("/", "scrap/root");
		VirtualDirectoryMetaData v = new VirtualDirectoryMetaData(dir);
		
	}

	@Test (expected = IllegalArgumentException.class)
	public void constructorShouldThrow() {
		
		VirtualDirectory dir = new VirtualDirectory("/", "scrap/root");
		VirtualDirectoryMetaData v = new VirtualDirectoryMetaData(null);
		
	}

}
