package edu.olemiss.csci211;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

/** An child class of {@link OutputStream} that writes bytes to a VirtualFile.
 * 
 * @author rhodes
 *
 */
public class VirtualFileOutputStream extends OutputStream {

	VirtualFile vFile;

	private int streamByteOffset=0;
	private int offsetOfBlockInStream = 0;
	private Iterator<IndexedFileBlock> streamBlockIterator=null;
	private byte[] streamBlockData = null;	

	
	/** Construct a new stream that writes to the given virtual file.
	 * 
	 * @param vf the virtual file to write to.
	 */
	public VirtualFileOutputStream(VirtualFile vf) {
		
		if(vf == null)
			throw new IllegalArgumentException("VirtualFile argument is null.");
		
		this.vFile = vf;
	}


	@Override
	public void write(int b) {
		

		if (this.streamBlockIterator == null) {
			
			this.streamBlockIterator = this.vFile.getBlocks().iterator();
			this.streamByteOffset = 0; // byte offset in stream. This is the offset of the byte we will return.
			this.offsetOfBlockInStream = 0;  // byte offset (in the stream) of element 0 of the current block
			this.streamBlockData = this.streamBlockIterator.next().data();
		}
				
		int byteOffsetWithinBlock = this.streamByteOffset - this.offsetOfBlockInStream;
		
		
		if ( byteOffsetWithinBlock < this.streamBlockData.length) {
			
			this.streamByteOffset++;
			this.streamBlockData[byteOffsetWithinBlock] = (byte) ( b & 0xFF);
			
		} else if (this.streamBlockIterator.hasNext()){
			
			// Get a new block from the iterator
			this.streamBlockData = this.streamBlockIterator.next().data();
			this.offsetOfBlockInStream = this.streamByteOffset;
			this.streamByteOffset++;
			this.streamBlockData[0] = (byte) ( b & 0xFF);
		} else {
			
			// make new block and add it to vtf
			this.streamBlockData = this.vFile.addNewBlock().data();
			
			// update stream state
			this.offsetOfBlockInStream = this.streamByteOffset;
			this.streamByteOffset++;
			// write the byte
			this.streamBlockData[0] = (byte) ( b & 0xFF);
			
			// make a new iterator
			this.streamBlockIterator = this.vFile.getBlocks().iterator();
			
			// advance the iterator to point to the new block.
			while(this.streamBlockIterator.next().data() != this.streamBlockData);
			
		}
	}
}


