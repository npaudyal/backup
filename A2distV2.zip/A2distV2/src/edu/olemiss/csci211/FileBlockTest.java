package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import org.junit.Test;

public class FileBlockTest {

	@Test
	public void constructorTestGoodFileValid() {
		// "A1UnitTestData/GoodFile" is a valid file with 512 data bytes
		FileBlock fb = new FileBlock("A1UnitTestData/GoodFile");
				
		assertTrue(fb.isValid());
	}

	@Test
	public void constructorTestGoodFileSize() {
		// "A1UnitTestData/GoodFile" is a valid file with 512 data bytes
		FileBlock fb = new FileBlock("A1UnitTestData/GoodFile");
				
		assertEquals(512, fb.size());
	}

	@Test
	public void constructorTestInValid() {
		// "A1UnitTestData/invalid" is an invalid file with 512 data bytes
		FileBlock fb = new FileBlock("A1UnitTestData/invalid");
				
		assertFalse(fb.isValid());
	}
	
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructorTestMissingFile() {
		
		// file doesn't exist
		new FileBlock("A1UnitTestData/missingFile");	
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructorTestEmptyFile() {
		
		// "A1UnitTestData/empty" is a file with 0 bytes
		new FileBlock("A1UnitTestData/empty");		
	}
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructorTestShortDataFile() {
		
		// "A1UnitTestData/short" has a checksum and size, but the data section is short
		new FileBlock("A1UnitTestData/short");		
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructorTestNoDataInFile() {
		// "A1UnitTestData/nodata" has a checksum and size, but no data at all.
		new FileBlock("A1UnitTestData/nodata");		
	}

	@Test
	public void readValid() throws IOException {
		
		// I just want to make a new FileBlock, but that class only
		// has one constructor.
		FileBlock fb = new FileBlock("A1UnitTestData/tiny");
		
		FileInputStream fis = new FileInputStream("A1UnitTestData/GoodFile");
		DataInputStream dis = new DataInputStream(fis);
		
		fb.read(dis);
		dis.close();
		
		assertTrue(fb.isValid());
	}


	@Test(expected = java.lang.IllegalArgumentException.class)
	public void readTestEmptyFile() throws IOException{
		
		// I just want to make a new FileBlock, but that class only
		// has one constructor.
		FileBlock fb = new FileBlock("A1UnitTestData/tiny");
		
		FileInputStream fis = new FileInputStream("A1UnitTestData/empty");
		DataInputStream dis = new DataInputStream(fis);
		
		fb.read(dis); // should throw
		dis.close();

	}
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void readTestShortDataFile() throws IOException{
		
		// I just want to make a new FileBlock, but that class only
		// has one constructor.
		FileBlock fb = new FileBlock("A1UnitTestData/tiny");
		
		FileInputStream fis = new FileInputStream("A1UnitTestData/short");
		DataInputStream dis = new DataInputStream(fis);
		
		fb.read(dis); // should throw
		dis.close();
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void readTestNoDataInFile() throws IOException{
		
		// I just want to make a new FileBlock, but that class only
		// has one constructor.
		FileBlock fb = new FileBlock("A1UnitTestData/tiny");
		
		FileInputStream fis = new FileInputStream("A1UnitTestData/nodata");
		DataInputStream dis = new DataInputStream(fis);
		
		fb.read(dis); // should throw
		dis.close();
	}
	

	
}
