package edu.olemiss.csci211;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class VirtualBackupTest {

	VirtualFile f1;
	VirtualFile f2;
	VirtualFile f3;
	VirtualFile f4;
	
	VirtualChangeSet c1;
	VirtualChangeSet c2;
	VirtualChangeSet c3;

	/** This method is run before each and every test. It makes some objects that are useful for testing.
	 * 
	 * @throws Exception if a constructor fails. 
	 */ 
	@Before
	public void setUp() throws Exception {
		
		VirtualFileMetaData fm1 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFileMetaData fm2 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f8", "A1UnitTestData/f3", "A1UnitTestData/f7", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		VirtualFileMetaData fm3 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f3", "A1UnitTestData/f8", "A1UnitTestData/f3", "A1UnitTestData/f7", "A1UnitTestData/f5", "A1UnitTestData/f4"}, Block.NO_CHECKSUM);
		VirtualFileMetaData fm4 = new VirtualFileMetaData( new String [] {"A1UnitTestData/f1", "A1UnitTestData/f2", "A1UnitTestData/f3", "A1UnitTestData/f4", "A1UnitTestData/f5", "A1UnitTestData/f6"}, Block.NO_CHECKSUM);
		
		this.f1 = new VirtualFile(fm1);		
		this.f2 = new VirtualFile(fm2);
		this.f3 = new VirtualFile(fm3);
		this.f4 = new VirtualFile(fm4);
		
		c1 = new VirtualChangeSet(f1,f2);
		c2 = new VirtualChangeSet(f2,f3);
		c3 = new VirtualChangeSet(f3,f4);
	}


	@Test
	public void constructorShouldntThrow() {

		VirtualBackup backup = new VirtualBackup(f1);
	}
	
	
	@Test
	public void getCurrentVersion() {
		
		long cs1 = f1.computeCheckSum();
		VirtualBackup backup = new VirtualBackup(f1);
		
		VirtualFile f3 = backup.getCurrentVersion();
		long cs2 = f3.computeCheckSum();
		
		assertEquals(cs1, cs2);
	}

	@Test
	public void apply() {
		
		VirtualBackup backup = new VirtualBackup(f1);
		
		VirtualFile f3 = backup.getCurrentVersion();
		long cs1 = f3.computeCheckSum();
		
		VirtualFile f4 = backup.apply(c1);
		long cs2 = f4.computeCheckSum();
		
		assertTrue( cs1 != cs2);
	}

	
	@Test
	public void applyUndo() {
		
		VirtualBackup backup = new VirtualBackup(f1);
		
		VirtualFile f3 = backup.getCurrentVersion();
		long cs1 = f3.computeCheckSum();
		
		backup.apply(c1);
		VirtualFile f4 = backup.undo();
		
		long cs2 = f4.computeCheckSum();
		
		assertTrue( cs1 == cs2);
	}

	@Test
	public void applyApply() {
		
		VirtualBackup backup = new VirtualBackup(f1);
		
		VirtualFile t3 = backup.getCurrentVersion();
		long cs1 = t3.computeCheckSum();
		
		VirtualFile t4 = backup.apply(c1);
		long cs2 = t4.computeCheckSum();
		
		VirtualFile t5 = backup.apply(c2);
		
		long cs3 = t5.computeCheckSum();
		
		assertTrue( (cs1 != cs2) && (cs2 != cs3));
	}

	@Test
	public void applyApplyUndo() {
		
		VirtualBackup backup = new VirtualBackup(f1);
		
		VirtualFile t3 = backup.getCurrentVersion();
		long cs1 = t3.computeCheckSum();
		
		VirtualFile t4 = backup.apply(c1);
		long cs2 = t4.computeCheckSum();
		
		backup.apply(c2);
		VirtualFile t5 = backup.undo();
			
		long cs3 = t5.computeCheckSum();
		
		assertTrue( (cs1 != cs2) && (cs2 == cs3));
	}

	@Test
	public void applyApplyApply() {
		
		VirtualBackup backup = new VirtualBackup(f1);
		
		VirtualFile t3 = backup.getCurrentVersion();
		long cs1 = t3.computeCheckSum();
		
		backup.apply(c1);
		backup.apply(c2);
		VirtualFile t5 = backup.apply(c3);
			
		long cs2 = t5.computeCheckSum();
		
		assertTrue(cs1 == cs2);
	}

	
	

}
