package edu.olemiss.csci211;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PathTest {

	VirtualDirectory d;
	VirtualDirectory d1;
	VirtualDirectory d2;
	VirtualFile f1;
	VirtualFile f2;
	
	
	@Before
	public void setUp() throws Exception {
		
		d = new VirtualDirectory("/","scrap/root");
		d1 = new VirtualDirectory("foo","scrap/foo");
		d2 = new VirtualDirectory("bar","scrap/bar");
		f1 = new VirtualFile("baz", "scrap/baz");
		f2 = new VirtualFile("boom", "scrap/boom");
	}

	@After
	public void tearDown() throws Exception {
	}
	
	
	@Test
	public void constructorShouldNOTthrow() {
	
		new Path(d);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void constructorShouldThrow() {
	
		new Path(null);
	}
	
	@Test 
	public void constructor() {
	
		Path p = new Path(d);
		
		assertEquals("//", p.toString());
	}

	@Test (expected = IllegalArgumentException.class)
	public void appendShouldThrow1() {
	
		Path p = new Path(d);
		p.append(null);		
	}

	@Test (expected = IllegalStateException.class)
	public void appendShouldThrow2() {
	
		Path p = new Path(d);
		p.setFile(f1);
		p.append(d1);		
	}


	@Test 
	public void append() {
	
		Path p = new Path(d);
		p.append(d1);
		
		assertEquals("//foo/", p.toString());
	}

	@Test 
	public void append2() {
	
		Path p = new Path(d);
		p.append(d1);
		p.append(d2);
		
		assertEquals("//foo/bar/", p.toString());
	}

	@Test (expected = IllegalArgumentException.class)
	public void setFileShouldThrow() {
	
		Path p = new Path(d);
		p.setFile(d1);
		
	}
	
	@Test 
	public void setFile1() {
	
		Path p = new Path(d);
		p.setFile(f1);
		
		assertEquals("//baz", p.toString());
	}

	@Test 
	public void setFile2() {
	
		Path p = new Path(d);
		p.append(d1);
		p.setFile(f1);
		
		assertEquals("//foo/baz", p.toString());
	}

	@Test 
	public void isFilePath1() {
	
		Path p = new Path(d);
		p.append(d1);
		p.setFile(f1);
		
		assertTrue(p.isFilePath());
	}

	@Test 
	public void isFilePath2() {
	
		Path p = new Path(d);
		p.append(d1);
		p.append(d2);
		
		assertFalse(p.isFilePath());
	}

	@Test 
	public void removeLast1() {
	
		Path p = new Path(d);
		p.append(d1);
		p.append(d2);
		p.removeLast();
		
		assertEquals("//foo/", p.toString());
	}

	@Test 
	public void removeLast2() {
	
		Path p = new Path(d);
		p.append(d1);
		p.append(d2);
		p.removeLast();
		p.removeLast();
		
		assertEquals("//", p.toString());
	}

	@Test 
	public void removeLast3() {
	
		Path p = new Path(d);
		p.append(d1);
		p.append(d2);
		p.removeLast();
		p.removeLast();
		int err = p.removeLast();
		
		assertEquals(Path.REMOVE_FIRST_DIR_ERR, err);
		assertEquals("//", p.toString());
	}

	
	@Test 
	public void getLastDirectory1() {
	
		Path p = new Path(d);
		p.append(d1);
		p.append(d2);
		
		assertEquals(d2, p.getLastDirectory());
	}
	
	@Test 
	public void getLastDirectory2() {
	
		Path p = new Path(d);
		p.append(d1);
		p.append(d2);
		p.setFile(f1);
		
		assertEquals(d2, p.getLastDirectory());
	}

	
	

	
	


}
