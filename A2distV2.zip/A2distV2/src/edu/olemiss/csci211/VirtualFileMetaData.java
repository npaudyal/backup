package edu.olemiss.csci211;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.zip.CRC32;

/** Maintains information about a {@link VirtualFile}. This class records a list of file names,
 * each referring to a REAL file corresponding to a block of the virtual file being described.
 * A checksum, meant to have been computed over all the blocks of the virtual file, is also 
 * maintained. 
 * 
 * @see CRC32
 * @see VirtualFile
 * @see FileBlock
 * 
 * @author rhodes
 *
 */
public class VirtualFileMetaData implements Writeable, Readable, Serializable{
	
	private long checksum=Block.NO_CHECKSUM;
	private ArrayList<String> blockfilenames = new ArrayList<String>();
	private String virtualFileName;
	private String blockFileBaseName;
	

	/** Construct a new VirtualFileMetaData object with the given blockfile names, and the checksum 
	 * computed over all the blocks 
	 * @param names an array of filenames of real block files
	 * @param checksum the checksum of the entire virtual file
	 * @throws IllegalArgumentException if names array or any element thereof is null
	 */
	public VirtualFileMetaData(String [] names, long checksum) { //constructor 1
		
		if (names == null || names.length==0)
			throw new IllegalArgumentException("Names array is null or zero length");
		
		for(String name:names) {
			if (name == null) {
				throw new IllegalArgumentException("Element of names array is null.");
			}
		}
		
		
		this.blockfilenames.addAll(Arrays.asList(names));
		this.checksum = checksum;
	}
 
	/** Construct a new VirtualFileMetaData object that describes the given VirtualFile. The
	 * filenames for all the FileBlocks and the checksum for the virtual file will be recorded.
	 * 
	 * @throws IllegalArgumentException if f is null
	 * @param f the VirtualFile to be described
	 */
	public VirtualFileMetaData(VirtualFile f) { //constructor 2
		
		if (f == null)
			throw new IllegalArgumentException("null VirtualFile");
		
		this.checksum = f.computeCheckSum();
		this.virtualFileName = f.virtualFileName();
		this.blockFileBaseName = f.blockFileBaseName();
		this.blockfilenames.addAll(Arrays.asList(f.getBlockFileNames())); 		
	}

	
	
	
	
	
	
	
	/** Construct a new VirtualFileMetaData object from the data contained in the REAL file with
	 * the given name. The file should have previously been written by {@link VirtualFileMetaData#write}
	 * 
	 * @param filename the name of the REAL file to open and read.
	 */
	public VirtualFileMetaData(String filename) { //constructor 3
		
		if(filename == null)
			throw new IllegalArgumentException("Filename was null.");
		
		this.read(filename);
	}
	
	
	// Making compiler happy.
	protected VirtualFileMetaData(int checksum) {
		
	
	}
	
	
	/** Create a new {@link VirtualFile} from this VirtualFileMetaData object. 
	 * Child classes of VirtualFileMetaData should override this method to create 
	 * child classes of VirtualFile, as appropriate.
	 * @return a new VirtualFile
	 */
	public VirtualFile createNewVirtualFile() {
		
		return new VirtualFile(this);
	}

	
	
	/** Add the given filename to the list of block file names. 
	 * 
	 * @param filename the string to be added.
	 * @throws IllegalArgumentException if filename is null or empty.
	 */
	public void addBlockFileName(String filename) {
		
		if(filename == null || filename.equals(""))
			throw new IllegalArgumentException("Filename was null or empty.");
		
		
		this.blockfilenames.add(filename);
	}

	
	
	/** Write the VirtualFileMetaData to the given stream.
	 *  The stream should already be open for writing.
	 * @param dos an open DataOutputStream
	 * @throws IllegalArgumentException if an IO error is encountered.
	 */
	public void write(DataOutputStream dos) {
		
		try {
			dos.writeLong(this.checksum);
			dos.writeInt(this.blockfilenames.size());
			
			for(String name:this.blockfilenames)
				dos.writeUTF(name);
			
		} catch(IOException e) {
			throw new IllegalArgumentException("Error writing to stream.");
		}
	}

	
	/** Write the VirtualFileMetaData to a file with the given name. If the file already
	 * exists, it will be overwritten. The file stream will be closed when
	 * writing is complete.
	 * @param filename the name of the file to write to.
	 * @throws IllegalArgumentException if an IO error is encountered.
	 */
	public void write(String filename) {
		
		try {
			FileOutputStream fos = new FileOutputStream(filename);
			DataOutputStream dos = new DataOutputStream(fos);
			
			write(dos);

			dos.close();
		} catch(IOException e) {
			throw new IllegalArgumentException("Error opening or writing to file.");
		}
	}

	/** Read the VirtualFileMetaData from the given input stream, which 
	 * should already be open for reading. 
	 * The input file should have been written previously with {@link #write(DataOutputStream)}).
	 * @param dis an open DataInputStream ready for reading.
	 * @throws IllegalArgumentException if the file can't be fully read, or the length of the names array (as read from the file) is zero.
	 */	
	public void read(DataInputStream dis) {
		
		try {
			this.checksum = dis.readLong();
			int size = dis.readInt();
			
			if(size == 0)
				throw new IllegalArgumentException("File has zero length blockfilenames array.");
			
			this.blockfilenames = new ArrayList<String>(size); 
			
			for(int i=0; i< size; i++) {
				
				this.blockfilenames.add(dis.readUTF());
			}	
		} catch(IOException e) {
			throw new IllegalArgumentException("Error when reading from stream.");
		}
	}
	
	
	/** Read the VirtualFileMetaData from a file with the given name.
	 * The input file should have been written with FileMetaData.write().
	 * The file will be closed before this method returns.
	 * @param dis an open DataInputStream ready for reading.
	 * @throws IllegalArgumentException if the file can't be fully read.
	 */	
	void read(String filename){
		
		try {
			FileInputStream fis = new FileInputStream(filename);
			DataInputStream dis = new DataInputStream(fis);
			
			this.read(dis);
						
			dis.close();
			fis.close();
		} catch(FileNotFoundException e){
			
			throw new IllegalArgumentException("Missing File.");
		} catch (IOException e) {
			
			throw new IllegalArgumentException("Bad File.");
		}
	}
	
	
	/** Get the names of the REAL files corresponding to the blocks of the VirtualFile
	 * described by this VirtualFileMetaData object. 
	 * 
	 * @return an array of String filenames
	 */
	String [] getBlockFileNames() { 
		
		int numNames = this.blockfilenames.size();
		String [] names = new String [numNames];
		
		return this.blockfilenames.toArray(names);
	}

	
	/** get the value of the checksum field meant to refer to the VirtualFile
	 * described by this VirtualFileMetaData object. 
	 * 
	 * @return the checksum value
	 */
	long getCheckSum() {
		
		return this.checksum;
	}

	/** Return the name of the virtual file represented by this VirtualFileMetaData object.
	 * 
	 * @return the virtual name
	 */
	public String virtualFileName() {
	
		return this.virtualFileName;
	}
	
	/** Return the prefix used by the VirtualFile when automatically generating new block files. 
	 * 
	 * @return the block prefix
	 */	
	public String blockFileBaseName() {
		
		return this.blockFileBaseName;
	}
	
}
