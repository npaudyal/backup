package edu.olemiss.csci211;

import java.util.NoSuchElementException;


/** A Path is a sequence of VirtualDirectories indicating a location in
 * a filesystem. A Path may also specify a file as its last component, in
 * which case it is considered to be a "file path", with the final file referred
 * to as the "file portion" of the path. In the absence of a file portion, a
 * path simply specifies how to get to the "last directory" in the sequence from some
 * starting directory. 
 * 
 * When printed as a string, Paths look like  "foo/bar/baz", or "//users/grandma/moses"
 * 
 * @author rhodes
 *
 */
public class Path {
	
	public static final int NO_ERR=0;
	public static final int REMOVE_FIRST_DIR_ERR=1;
	
	// TODO 75  Pick a data structure to hold your virtual directories.
	
	// I suggest a separate field to hold a filename for the "file portion" of
	// the path, if any.
	private VirtualFile vfile;
	
	
	/** Construct a Path beginning with the given directory. 
	 * 
	 * @param d the first directory in the path
	 * @throws IllegalArgumentException if the given directory is null
	 */
	public Path(VirtualDirectory d) {

		// TODO 75
	}

	/** Add the given directory to the end of the sequence of directories already
	 * in the Path.
	 * 
	 * @param d the directory to be added
	 * @throws IllegalStateException if this path has a file name set using setFile()
	 * @throws IllegalArgumentException if the given directory is null
	 */
	public void append(VirtualDirectory d) {
		
		// TODO 75
	}
	
	/** Add the given file to the end of this Path, making this path a 
	 * "file path".
	 * 
	 * @param f a VirtualFile 
	 * @throws IllegalArgumentException if the argument is not a simple VirtualFile (a child class of VirtualFile)
	 */
	public void setFile(VirtualFile f) {
		
		// implementation note: you might want to have a separate data member for storing a file.
		
		// TODO 75
		
	}

	/** Return the file portion of this Path, or null if no file portion exists.
	 * 
	 * @return a VirtualFile, or null
	 */
	public VirtualFile getFile() {
		
		// TODO 75
		return null;
	}
	
	/** Return true if this Path has had the file portion set via setFile()
	 * 
	 * @return true if a file portion is set, false otherwise.
	 */
	public boolean isFilePath() {
		
		// TODO 75
		return false;
	}
	

	/** Remove the last component of the Path. If this path has a file portion,
	 * then it will be removed, effectively undoing setFile(). Otherwise, the 
	 * last directory in the path will be removed, unless this directory is at the
	 * beginning of the Path. If removeLast() is called on a Path with only one 
	 * directory, this method returns {@link Path#REMOVE_FIRST_DIR_ERR}. Otherwise,
	 * {@link Path#NO_ERR} is returned.
	 * 
	 * @return NO_ERR if successful, REMOVE_FIRST_DIR_ERR otherwise.
	 */
	public int removeLast() {
		
		// TODO 75
		return 0;
				
	}
	
	/** Return the last directory of the sequence of directories in this
	 * Path. This method ignores the file portion of the path, if any.
	 * 
	 * @return The last directory in the path.
	 */
	public VirtualDirectory getLastDirectory() {
		
		// TODO 75
		return null;
		
	}
	
	
	/** Return a string representing this path. Examples include "/foo/bar/image",
	 *  "//users/smith/", and "//". Unlike directory paths, file paths do not end in "/". 
	 * 
	 * @return a string
	 */
	public String toString() {
		
		// TODO 75  uncomment and adapt as necessary.
		
//		String result="";
//		for(VirtualDirectory d:vdirs) {
//			
//			result = d.virtualFileName() + "/" + result;
//		}
//		
//		if (isFilePath())
//			result += vfile.virtualFileName();
//		
//		return result;
		
		return "not implemented";
	}
	
	
	
}
