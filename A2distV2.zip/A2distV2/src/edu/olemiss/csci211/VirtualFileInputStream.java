package edu.olemiss.csci211;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;


/** An implementation of InputStream that reads byte data from a VirtualFile.
 * 
 * @author rhodes
 *
 */

public class VirtualFileInputStream extends InputStream {
	
	private VirtualFile vFile;
	
	private int streamByteOffset=0;
	private int offsetOfBlockInStream = 0;
	private Iterator<IndexedFileBlock> streamBlockIterator=null;
	private byte[] streamBlockData = null;	

	
	public VirtualFileInputStream(VirtualFile vf) {
		
		this.vFile = vf;
	}

	
	@Override
	public int read() throws IOException {
		
		if (this.streamBlockIterator == null) { // we need a new iterator.
			
			this.streamBlockIterator = this.vFile.getBlocks().iterator();
			this.streamByteOffset = 0; // byte offset in stream. This is the offset of the byte we will return.
			this.offsetOfBlockInStream = 0;  // byte offset (in the stream) of element 0 of the current block
			this.streamBlockData = this.streamBlockIterator.next().data();
		}
				
		int byteOffsetWithinBlock = this.streamByteOffset - this.offsetOfBlockInStream;
		
		
		if ( byteOffsetWithinBlock < this.streamBlockData.length) {
			
			this.streamByteOffset++;
			return (this.streamBlockData[byteOffsetWithinBlock] & 0xFF);
		} else if (this.streamBlockIterator.hasNext()){
			
			// Get a new block.
			this.streamBlockData = this.streamBlockIterator.next().data();
			this.offsetOfBlockInStream = this.streamByteOffset;
			this.streamByteOffset++;
			return (this.streamBlockData[0] & 0xFF); // return first element of new block.
		} else {
			this.streamBlockIterator = null;
			return -1;
		}
	}
}
