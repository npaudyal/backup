package edu.olemiss.csci211;

import java.io.Serializable;
import java.util.NoSuchElementException;

/** A linked implementation of the Queue interface. 
 * 
 * @author rhodes
 *
 * @param <E> the type of elements stored in the queue.
 */
public class LinkedQueue<E> implements Queue<E>{

	protected class Node implements Serializable{
		
		E element;
		Node next;
	}
	
	private Node head, end;
	private int size = 0;
	
	
	/**
	 *  Construct an empty queue.
	 */ 
	public LinkedQueue(){
		
		head=end=null;
		size = 0;
	}

	/**
	 * @see #enqueue
	 */
	@Override
	public void add(E element) {
		
		enqueue(element);
	}


	
	
	@Override // see interface for comments.
	public void enqueue(E element) {

		Node n = new Node();
		n.element = element;
		n.next = null;
		
		if(end == null){
			head = end = n;
			
		} else {
			
			end.next = n;
			end=n;
		}
		size++;
	}
	
	@Override // see interface for comments.
	public void clear() {
		
		this.head = this.end = null;
		this.size = 0;
	}

	/**
	 *  Remove the element at the head of the queue, and return it.
	 *  @see #dequeue
	 *  @return the removed element
	 *  @throws NoSuchElementException if the queue is empty.
	 */
	public E remove() {
	
		return dequeue();
	}
	
	
	/**
	 *  @return the removed element
	 *  @throws NoSuchElementException if the queue is empty.
	 */	
	@Override // see interface for comments.
	public E dequeue() {
		
		if( head == null){
			
			throw new NoSuchElementException("Remove: Queue is empty.");
		}
		
		E r = head.element;
		
		if( end == head) {
			
			end = null;
		}
		
		head = head.next;
		
		size--;
		return r;
	}

	@Override // see interface for comments.
	public int size() {
		
		return size;
	}

	/** An Iterator for our LinkedQueue.
	 * 
	 * @author rhodes
	 *
	 */
	private class LinkedQueueIterator implements PeekIterator<E> {
		
		LinkedQueue<E>.Node current;
		
		public LinkedQueueIterator(LinkedQueue<E> q){
			
			current = q.head;
		}
		
		@Override // see interface for comments.
		public boolean hasNext() {
			
			return (current != null);
		}

		@Override
		public E next() {

			E r = current.element;
			
			current = current.next;
			
			return r;
		}

		@Override
		public E peek() {
			
			if (current!=null)
				return current.element;
			else
				return null;
		}

		
	}

	@Override // see interface for comments.
	public PeekIterator<E> iterator(){
		
		return new LinkedQueueIterator(this);
	}


	
}
