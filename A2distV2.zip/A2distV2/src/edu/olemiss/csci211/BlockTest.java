package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.junit.Test;

public class BlockTest {

	@Test
	public void constructor1MakesValidBlock() {
		
		Block b = new Block(512);
		
		assertTrue(b.isValid());
	}

	
	@Test
	public void constructor1CorrectBlockSize() {
		
		Block b = new Block(512);
		
		assertEquals(512, b.size());
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructor1NegativeBlockSizeThrows() {
		
		new Block(-1);
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructor1ZeroBlockSizeThrows() {
		
		new Block(0);
	}

	@Test
	public void constructor2NoThrow() {
		
		new Block(new byte [] {0,0,0,0,0});
	}
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructor2NullShouldThrow() {
		
		new Block((byte [])null);
	}
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructor2ZeroLengthShouldThrow() {
		
		new Block(new byte [] {});
	}

	@Test
	public void constructor2ValidBlock() {
		
		Block b = new Block(new byte [] {2,0,1,0,1});
		assertTrue(b.isValid());
	}

	@Test
	public void constructor2Size() {
		
		Block b = new Block(new byte [] {2,0,1,0,1});
		
		//System.out.println(b.checkSum());
		assertEquals(5, b.size());
	}

	@Test
	public void constructor3NoThrow() {
		
		new Block(0, new byte [] {0,0,0,0,0});
	}
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructor3NullShouldThrow() {
		
		new Block(0, null);
	}
	
	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructor3ZeroLengthShouldThrow() {
		
		new Block(0, new byte [] {});
	}

	@Test
	public void constructor3ValidBlock() {
		
		Block b = new Block(3391618780L, new byte [] {2,0,1,0,1});
		assertTrue(b.isValid());
	}

	@Test
	public void constructor3InValidBlock() {
		
		Block b = new Block(3391618781L, new byte [] {2,0,1,0,1});
		assertFalse(b.isValid());
	}

	@Test
	public void constructor3Size() {
		
		Block b = new Block(new byte [] {2,0,1,0,1});
		assertEquals(5, b.size());
	}

	@Test(expected = java.lang.IllegalArgumentException.class)
	public void constructor4NullShouldThrow() {
		
		new Block((Block)null);
	}

	
	
	@Test
	public void writeNoThrow() throws IOException{
		
		Block b = new Block(new byte [] {2,0,1,0,1});
		
		FileOutputStream fos = new FileOutputStream("testfile");
		DataOutputStream dos = new DataOutputStream(fos);
		
		b.write(dos);
		
		dos.close();
	}
	
	@Test
	public void writeTestLength() throws IOException{
		
		Block b = new Block(new byte [] {2,0,1,0,1});
		
		FileOutputStream fos = new FileOutputStream("testfile");
		DataOutputStream dos = new DataOutputStream(fos);
		
		b.write(dos);
				
		dos.close();
		
		// file should be 17 bytes long. (5 data bytes, 4 for the size, 8 for the checksum)
		assertEquals(17, new File("testfile").length());
	}

}
