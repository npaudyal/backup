package edu.olemiss.csci211;

import java.util.zip.CRC32;

/** A VirtualBackup is a sequence of {@link VirtualChangeSet}s paired with a full backup of a {@link VirtualFile}. Each ChangeSet can
 * be applied in succession, producing a new version of the TapeFile by replacing blocks with new, updated blocks. (ChangeSets are
 * a kind of incremental backup.) 
 * <p>
 * Once a VirtualChangeSet has been applied, it can also be undone, producing the previous version of the TapeFile. Once all ChangeSets
 * have been undone, the Backup version is identical to the full backup of the VirtualTapeFile (the original file state). Similarly, ChangeSets that
 * have been undone can be redone, letting the user search back and forth for the desired version of the file.  
 * <p>
 * At any time, the {@link #getCurrentVersion()} method can be called to retrieve the current version of the TapeFile from the Backup.
 * 
 * 
 * @author rhodes
 *
 */
public class VirtualBackup {
	
	Stack<VirtualChangeSet> applied = new LinkedStack<VirtualChangeSet>();
	Stack<VirtualChangeSet> undone = new LinkedStack<VirtualChangeSet>();
	
	VirtualFile full;
	
	VirtualFile current;
	
	/** Construct a new VirtualBackup that will use the given VirtualTapeFile as the full backup. 
	 * 
	 * @param f a complete VirtualTapeFile 
	 */
	public VirtualBackup(VirtualFile f) {
		
		this.full = f;
		this.current = this.full;
	}
	
	/** Return the current version of the VirtualTapeFile. If no VirtualChangeSet has been applied, the current version
	 * is identical to the full backup. If one or more {@link VirtualChangeSet}s have been applied, the current version
	 * will reflect the block substitutions specified by each applied changeset. 
	 * 
	 * @return the current version of the VirtualTapeFile
	 */
	public VirtualFile getCurrentVersion() {
		
		return this.current;
	}
	
	/** Apply the given VirtualChangeSet to the current version of the VirtualTapeFile,
	 * producing a new current version that includes the changes specified by the VirtualChangeSet.
	 * 
	 * @param c the VirtualChangeSet to be applied.
	 * @return the new current version of the VirtualTapeFile
	 */
	public VirtualFile apply(VirtualChangeSet c) {
		
		c.applyTo(this.current);
		
		applied.push(c);
		
		return this.current;
	}
	
	/** Undo the most recently applied VirtualChangeSet, producing a current version of the VirtualTapeFile
	 * that is identical to the version that existed before the most recent VirtualChangeSet was applied.
	 * 
	 * @return the new current version of the VirtualTapeFile
	 */
	public VirtualFile undo() {
		
		VirtualChangeSet c = applied.pop();
		
		c.undo(this.current);
		
		this.undone.push(c);
	
		return this.current;
	}
	
	/** Redo the most recently undone VirtualChangeSet, producing a current version of the VirtualTapeFile
	 * that is identical to the version that existed before the VirtualChangeSet was undone.
	 * 
	 * @return the new current version of the VirtualTapeFile
	 */
	
	public VirtualFile redo() {
		
		VirtualChangeSet c = undone.pop();
		
		c.applyTo(this.current);
		
		this.applied.push(c);
		
		return this.current;
	}
	
	/**  Compute the {@link CRC32} checksum over the current version of the VirtualTapeFile that this Backup represents
	 *  @see VirtualFile
	 * 
	 * @return the checksum for the current version of the VirtualTapeFile
	 */
	public long computeCheckSum() {
		
		return this.current.computeCheckSum();
	}


}
