package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;




public class L085Tests {

	@After
	public void tearDown() {
		
		// clean up the scrap directory
		for(File file : new File("./scrap").listFiles()) {
		    if (!file.isDirectory() && !file.isHidden()) {
		    	//System.out.println("deleting "+ file);
		        file.delete();
		    }
		}
	}

	
	//////////////////////VirtualDirectory.createFromFile////////////////////
	@Test
	public void createFromFileEmptyDirShouldNOTthrow() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		root.writeToFile();
		
		root=null;
				
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
	}

	
	@Test
	public void createFromFile1() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		// A simple example of an image file.
		VirtualFile hamster = new VirtualFile("hamster", "scrap/hamster");
		//hamster.importFile("images/hamster.jpg");
		root.addSubFile(hamster);

		root.writeToFile();
		root = null;
		
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("hamster", newdir.ls());
	}

	@Test
	public void createFromFile2() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		
		VirtualFile hamster = new VirtualFile("hamster", "scrap/hamster");
		//hamster.importFile("images/hamster.jpg");
		root.addSubFile(hamster);

		root.writeToFile();
		root = null;
		
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("hamster", newdir.ls());
	}
	
	@Test
	public void createFromFile3() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory home = new VirtualDirectory("home", "scrap/home");
		
		root.addSubFile(home);
		
		root.writeToFile();
		root = null;
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("home", newdir.ls());
		
	}

	@Test
	public void createFromFile4() throws IOException {

		// make a root directory
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		VirtualDirectory home = new VirtualDirectory("home", "scrap/home");
		
		VirtualFile hamster = new VirtualFile("hamster", "scrap/hamster");
		//hamster.importFile("images/hamster.jpg");

		root.addSubFile(hamster);
		
		
		root.addSubFile(home);
		
		root.writeToFile();
		root = null;
		
		VirtualDirectory newdir = VirtualDirectory.createFromFile("scrap/root");
		
		assertEquals("hamster home", newdir.ls());
		
	}

	////////////////////	VirtualDirectory.dirByVirtualFileName  //////////////////
	
	@Test
	public void dirByVirtualFileName1() {
		
		VirtualDirectory vd1 = new VirtualDirectory("d1", "scrap/d1");
		VirtualFile vf2 = new VirtualFile("t2", "scrap/t2");
		VirtualFile vd3 = new VirtualDirectory("d3", "scrap/d3");
		
		VirtualDirectory vdir = new VirtualDirectory("root", "scrap/root");
		
		vdir.addSubFile(vd1);
		vdir.addSubFile(vf2);
		vdir.addSubFile(vd3);
		
		//System.out.println(vdir.dir());
		
		String result = vdir.dirByVirtualFileName();
		
		//System.out.println(result);
		
		assertEquals(	"NAME	TYPE	BYTES	BLOCKS\n" + 
						".	dir	512	1\n" + 
						"d1	dir	512	1\n" + 
						"d3	dir	512	1\n" + 
						"t2	file	512	1\n" , result);
	}

	@Test
	public void dirByVirtualFileName2() {
		
		VirtualDirectory vd1 = new VirtualDirectory("x1", "scrap/d1");
		VirtualFile vf2 = new VirtualFile("t2", "scrap/t2");
		VirtualFile vd3 = new VirtualDirectory("a3", "scrap/d3");
		
		VirtualDirectory vdir = new VirtualDirectory("root", "scrap/root");
		
		vdir.addSubFile(vd1);
		vdir.addSubFile(vf2);
		vdir.addSubFile(vd3);
		
		//System.out.println(vdir.dir());
		
		String result = vdir.dirByVirtualFileName();
		
		//System.out.println(result);
		
		assertEquals(	"NAME	TYPE	BYTES	BLOCKS\n" + 
						".	dir	512	1\n" + 
						"a3	dir	512	1\n" + 
						"t2	file	512	1\n" + 
						"x1	dir	512	1\n" , result);
	}


	@Test
	public void dirByVirtualFileSize1() throws IOException {
		
		VirtualDirectory vd1 = new VirtualDirectory("x1", "scrap/d1");
		VirtualFile vf2 = new VirtualFile("a2", "scrap/t2");
		VirtualFile vf3 = new VirtualFile("y3", "scrap/d3");
		VirtualFile vd4 = new VirtualDirectory("c4", "scrap/d4");
		
		VirtualDirectory vdir = new VirtualDirectory("root", "scrap/root");
		
		vdir.addSubFile(vd1);
		vdir.addSubFile(vf2);
		vdir.addSubFile(vf3);
		vdir.addSubFile(vd4);
		
		java.nio.file.Path path = FileSystems.getDefault().getPath("./UnitTestData/f1");
		Files.copy(path, new VirtualFileOutputStream(vf2));

		path = FileSystems.getDefault().getPath("./UnitTestData/f4");
		Files.copy(path, new VirtualFileOutputStream(vf3));

		vdir.flush();
				
		String result = vdir.dirByVirtualFileSize();
		
		System.out.println(result);
		
		assertEquals(	"NAME	TYPE	BYTES	BLOCKS\n" + 
						".	dir	1024	2\n" + 
						"x1	dir	512	1\n" + 
						"a2	file	512	1\n" + 
						"c4	dir	512	1\n" + 
						"y3	file	2048	4\n"  , result);
	}

	@Test
	public void dirByVirtualFileSize2() throws IOException {
		
		VirtualFile vf1 = new VirtualFile("a1", "scrap/d1");
		VirtualFile vf2 = new VirtualFile("b2", "scrap/t2");
		VirtualFile vf3 = new VirtualFile("c3", "scrap/d3");
		VirtualFile vf4 = new VirtualFile("d4", "scrap/d4");
		VirtualFile vf5 = new VirtualFile("e5", "scrap/d5");
		VirtualFile vf6 = new VirtualFile("f6", "scrap/d6");
		VirtualFile vf7 = new VirtualFile("g7", "scrap/d7");
		
		VirtualDirectory vdir = new VirtualDirectory("root", "scrap/root");
		
		vdir.addSubFile(vf1);
		vdir.addSubFile(vf2);
		vdir.addSubFile(vf3);
		vdir.addSubFile(vf4);
		vdir.addSubFile(vf6);
		vdir.addSubFile(vf5);
		vdir.addSubFile(vf7);

		java.nio.file.Path path = FileSystems.getDefault().getPath("./UnitTestData/f5");
		Files.copy(path, new VirtualFileOutputStream(vf2));

		path = FileSystems.getDefault().getPath("./UnitTestData/f5");
		Files.copy(path, new VirtualFileOutputStream(vf1));

		path = FileSystems.getDefault().getPath("./UnitTestData/f4");
		Files.copy(path, new VirtualFileOutputStream(vf3));

		path = FileSystems.getDefault().getPath("./UnitTestData/f4");
		Files.copy(path, new VirtualFileOutputStream(vf5));

		path = FileSystems.getDefault().getPath("./UnitTestData/f5");
		Files.copy(path, new VirtualFileOutputStream(vf7));
	
		
		vdir.flush();
		
		//System.out.println(vdir.dir());
		
		String result = vdir.dirByVirtualFileSize();
		
		System.out.println(result);
		
		assertEquals(	"NAME	TYPE	BYTES	BLOCKS\n" + 
						".	dir	1536	3\n" + 
						"d4	file	512	1\n" + 
						"f6	file	512	1\n" + 
						"c3	file	2048	4\n" + 
						"e5	file	2048	4\n" + 
						"a1	file	2560	5\n" + 
						"b2	file	2560	5\n" + 
						"g7	file	2560	5\n", result);
	}

	////////////////////VirtualDirectory.du()  //////////////////
	
	
	
	@Test
	public void duShouldNOTthrow() {
		
		VirtualDirectory vd1 = new VirtualDirectory("x1", "scrap/d1");
		
		vd1.du();
	}

	@Test
	public void du1() {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		VirtualFile vf1 = new VirtualFile("f1", "scrap/vf1");
		VirtualFile vf2 = new VirtualFile("f2", "scrap/vf2");

		root.addSubFile(vf1);
		root.addSubFile(vf2);
		
		long uf1 = vf1.du();
		long uf2 = vf2.du();
		long ufr = root.size(); // the size of the root directory file itself
		
		long ur  = root.du();
		
		assertEquals(ur, uf1+uf2+ufr);
	}
	
	
	@Test
	public void du2() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		VirtualFile vf1 = new VirtualFile("f1", "scrap/vf1");
		VirtualFile vf2 = new VirtualFile("f2", "scrap/vf2");

		root.addSubFile(vf1);
		root.addSubFile(vf2);
		
		java.nio.file.Path path = FileSystems.getDefault().getPath("./UnitTestData/f5");
		Files.copy(path, new VirtualFileOutputStream(vf2));
		
		root.flush();
		
		long uf1 = vf1.du();
		long uf2 = vf2.du();
		long ufr = root.size(); // the size of the root directory file itself
		
		long ur  = root.du();   // the total size of root, and all its subfiles/subdirectories
		
		assertEquals(512, uf1);
		assertEquals(ur, uf1 + uf2 + ufr);
	}

	@Test
	public void du3() throws IOException {
		
		VirtualDirectory root = new VirtualDirectory("/", "scrap/root");
		
		VirtualFile vf1 = new VirtualFile("f1", "scrap/vf1");
		VirtualFile vf2 = new VirtualFile("f2", "scrap/vf2");
		VirtualDirectory vd3 = new VirtualDirectory("d3", "scrap/vd3");
		VirtualFile vf4 = new VirtualFile("f4", "scrap/vf4");
		VirtualFile vf5 = new VirtualFile("f5", "scrap/vf5");

		root.addSubFile(vf1);
		root.addSubFile(vf2);
		root.addSubFile(vd3);
		
		vd3.addSubFile(vf4);
		vd3.addSubFile(vf5);
		
		java.nio.file.Path path = FileSystems.getDefault().getPath("./UnitTestData/f5");
		Files.copy(path, new VirtualFileOutputStream(vf2));

		path = FileSystems.getDefault().getPath("./UnitTestData/f3");
		Files.copy(path, new VirtualFileOutputStream(vf4));

		path = FileSystems.getDefault().getPath("./UnitTestData/f2");
		Files.copy(path, new VirtualFileOutputStream(vf5));

		root.flush();
		
		long uf1 = vf1.du();
		long uf2 = vf2.du();
		long ud3 = vd3.du();
		long ufr = root.size(); // the size of the root directory file itself
		
		long ur  = root.du();   // the total size of root, and all its subfiles/subdirectories
		
		assertEquals(512, uf1);
		assertEquals(ur, uf1 + uf2 + ufr + ud3);
	}

	
	

	
}
