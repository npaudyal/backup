/**
 * 
 */
package edu.olemiss.csci211;

import java.util.Iterator;

/**

 * This interface adds a peek() method to the standard Iterator interface.
 * @author rhodes
 * @deprecated the semantics of the "current" versus the "next" element are too confusing to be useful.
 */
public interface PeekIterator<E> extends Iterator<E> {
	
	/** Return a reference to the current value of the iteration. Unlike next(),
	 * this method does not advance the iteration.
	 * 
	 * @return a reference to the current value of the iteration, or null if the iteration is finished.
	 */
	public E peek();
}
