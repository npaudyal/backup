package edu.olemiss.csci211;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

import org.junit.Test;

public class ShellTest {

	@Test
	public void helpTest() throws UnsupportedEncodingException {
		
		VirtualDirectory root = new VirtualDirectory("/","scrap/root");
		
		String testinput = "help\nq\n";
		ByteArrayInputStream  bais = new ByteArrayInputStream(testinput.getBytes("UTF-8"));
		ByteArrayOutputStream baos = new ByteArrayOutputStream(1000);
		PrintStream ps = new PrintStream(baos);
		Shell s = new Shell(root, bais, ps);
		s.run();
		
		assertEquals(	"Welcome to the A2 interactive shell.\n" + 
				">Commands are: cd <dirname | ..>, dir <-, -n, -s>, ls, pwd, find <filename>, du, open <filename>.  Type 'quit' or 'exit' to exit.\n" + 
				">\n" + 
				"bye.\n", baos.toString());
	}

	
	// This test needs Path in order to succeed.
	@Test
	public void cdTest() throws UnsupportedEncodingException {
		
		VirtualDirectory root = new VirtualDirectory("/","scrap/root");
		
		String testinput = "cd ..\nq\n";
		ByteArrayInputStream  bais = new ByteArrayInputStream(testinput.getBytes("UTF-8"));
		ByteArrayOutputStream baos = new ByteArrayOutputStream(1000);
		PrintStream ps = new PrintStream(baos);
		Shell s = new Shell(root, bais, ps);
		s.run();
		
		//System.out.println(baos.toString());
		assertEquals(	"Welcome to the A2 interactive shell.\n" + 
						">Already at /\n" + 
						">\n" + 
						"bye.\n", baos.toString());
	}

	
	
}
