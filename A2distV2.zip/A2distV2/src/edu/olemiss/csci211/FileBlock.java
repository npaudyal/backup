package edu.olemiss.csci211;

import java.io.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.zip.CRC32;

/** The FileBlock class extends Block to add the ability to
 *  read Block data from a file. The file contents should have
 *  previously been written by Block.write()
 * 
 * @author rhodes
 *
 */
public class FileBlock extends Block implements Readable{
	
	String filename;	
	
	/** Construct a block from the given input file. 
	 * The input file should have been written with Block.write(),
	 * and consists of a checksum (long), a size (int), and a
	 * sequence of _size_ bytes.
	 * @param filename the name of the file to be read.
	 * @throws IllegalArgumentException if the file can't be fully read.
	 */
	public FileBlock(String filename){
		
		this.filename = filename;
	
		load(filename);
	}
	
	
	public FileBlock(String filename, int filesize){
		
		this.filename = filename;
	
		try {
			load(filename);
		} catch (IllegalArgumentException e) {
			
			// Apparently, the load() failed, so we'll get an instance of Block
			// to make a new file with the correct format.
			Block n = new Block(filesize);
			n.write(filename);
			
			// Then we'll load the newly created file.
			load(filename);
		}
	}

	
	
	/** This copy constructor makes a copy of the given block. 
	 * 
	 * @param b the block to copy.
	 */
	public FileBlock(FileBlock b) {
		
		super(b);
		
		this.filename = b.getFileName();	
	}

	/** Set the contents of this Block to be a copy of the given block. 
	 * 
	 *  @param newblock the block to be copied
	 */
	public void assign(FileBlock newblock) {
		
		super.assign(newblock);

		this.filename = newblock.filename;
	}

	
	/** Read a block from the given input stream, which 
	 * should already be open for reading. 
	 * The input file should have been written with Block.write(),
	 * and consists of a checksum (long), a size (int), and a
	 * sequence of _size_ bytes.
	 * @param dis an open DataInputStream ready for reading.
	 * @throws IllegalArgumentException if the file can't be fully read.
	 */	
	public void read(DataInputStream dis) {
		
		try {
			this.checksum = dis.readLong();
			int size = dis.readInt();
			this.data = new byte[size];
			
			
			
			if(dis.read(this.data) != size) {
				
				throw new IllegalArgumentException("Couldn't read complete data from stream.");
			}	
		} catch(IOException e) {
			
			throw new IllegalArgumentException("Error when reading from stream.");
		}
	}
	
	
	
	void load(String filename){
		
		try {
			FileInputStream fis = new FileInputStream(filename);
			DataInputStream dis = new DataInputStream(fis);
			
			this.read(dis);
						
			dis.close();
			fis.close();
		} catch(FileNotFoundException e){
			
			throw new IllegalArgumentException("Missing File:" + filename);
		} catch (IOException e) {
			
			throw new IllegalArgumentException("Bad File.");
		}
	}
	
	String getFileName() {
		
		return this.filename;
	}
	
	public void write() {
		
		super.write(this.filename);
	}
	
	
}
