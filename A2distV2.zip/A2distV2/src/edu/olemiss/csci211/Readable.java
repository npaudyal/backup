package edu.olemiss.csci211;

import java.io.DataInputStream;


/** An interface for classes that can read themselves from a file.
 * 
 * @author rhodes
 *
 */
public interface Readable {
	
	/** Read the object from the given stream.
	 *  The stream should already be open for reading.
	 * @param dis an open DataInputStream
	 * @throws IllegalArgumentException if the stream can't be read.
	 */
	void read(DataInputStream dis);
}
